########################################################################################################################################################
# The following is a kernels file for a  minimum-requisite and dependency python script to calculate mantle flow field for the Blankenbach et al.      #
# (1989) mantle convection benchmark.                                                                                                                  #  
# It still has routines to calculate volcanic heat transport, and transport thermal effects. These have been skipped in this setup though.             #
# The thermal convection solver has been benchmarked using both BGK and TRT schemes *this is tyhe BGK benchmark.    Full implementation is to be       #
# presented in expanded upcoming publications. Please see https://github.com/thecraigoneill/planet_LB for the up to date core code archive.            #
########################################################################################################################################################
#CUDA kernels for the D2Q9 lattice Boltzmann mantle convection solver Cthonian. 
#  Switching from the old @njit(parallel=True) CPU kernels, to numba.cuda @cuda.jit kernels, for speed (if you have cuda).
# Some Notes
#------------
#* Lattice fields stay resident on the GPU across timesteps. The only
#  device<->host traffic during the run is (a) a 2-double min/max buffer
#  reset each step, and (b) field copies at diagnostic/snapshot intervals.
#* Streaming uses a pair (f, ftmp) pull-scheme with, periodic
#  BC, same as `(i-1) % (n+1)` indexing in the CPU code,
#  followed by the same bounce-back / thermal BC overwrites at the walls.
#* Boundary-condition kernels are launched sequentially so corner nodes
#  see the same left->right->bottom->top ordering, same as the CPU code.
#
#Set NUMBA_ENABLE_CUDASIM=1 before import to run on the CPU simulator
# (which will be pretty slow, but there is no cuda on a mac, for eg.).


###################### MIT LICENSING ###########################################
#
#
#Copyright 2024 Dr Craig O'Neill
#
#Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
################################################################################ 


import math
import numpy as np
from numba import cuda

# ------------------------------------------------------------------ #
# Launch configuration helpers
# ------------------------------------------------------------------ #
TPB2D = (16, 16)   # threads per block, 2D kernels
TPB1D = 128        # threads per block, 1D boundary kernels


def grid2d(n, m):
    """Blocks needed to cover an (n+1) x (m+1) grid."""
    bx = (n + 1 + TPB2D[0] - 1) // TPB2D[0]
    by = (m + 1 + TPB2D[1] - 1) // TPB2D[1]
    return (bx, by)


def grid1d(length):
    return (length + TPB1D - 1) // TPB1D


# ------------------------------------------------------------------ #
# Reductions
# ------------------------------------------------------------------ #
@cuda.jit
def k_minmax(th, out2):
    """Atomic min/max of th into out2[0]=min, out2[1]=max.
    out2 must be reset to (+inf, -inf) before launch."""
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        v = th[i, j]
        cuda.atomic.min(out2, 0, v)
        cuda.atomic.max(out2, 1, v)


# ------------------------------------------------------------------ #
# Velocity (f) field kernels
# ------------------------------------------------------------------ #
@cuda.jit
def k_force(w, cx, cy, gbeta, gbeta10, th, minmax_th, dens, rho, F,
            cdens_ref, cdens_span):
    """Gravity/buoyancy force term. tref = (min(th)+max(th))/2, read from
    the device reduction buffer to avoid a host sync.
    cdens = 0.5 + (cdens_ref - dens)/cdens_span, with cdens_ref/cdens_span
    supplied from the driver (were 2900 and 3400-2900=500)."""
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        tref = (minmax_th[0] + minmax_th[1]) / 2.0
        cdens = 0.5 + (cdens_ref - dens[i, j]) / cdens_span
        buoy = gbeta * (th[i, j] - tref) * rho[i, j]
        cbuoy = gbeta10 * cdens * rho[i, j]
        for k in range(9):
            F[k, i, j] = 3.0 * w[k] * cy[k] * (buoy + cbuoy)


@cuda.jit
def k_feq(vx, vy, cx, cy, rho, w, feq):
    """Equilibrium distribution (loopy_loop)."""
    i, j = cuda.grid(2)
    if i < vx.shape[0] and j < vx.shape[1]:
        t1 = vx[i, j] * vx[i, j] + vy[i, j] * vy[i, j]
        for k in range(9):
            t2 = vx[i, j] * cx[k] + vy[i, j] * cy[k]
            feq[k, i, j] = rho[i, j] * w[k] * (1.0 + 3.0 * t2 + 4.50 * t2 * t2 - 1.50 * t1)


@cuda.jit
def k_clamp_volc(Volc):
    """In-place clamp of Volc to [-1, 1] (matches LB_D2Q9_V filt4 logic)."""
    i, j = cuda.grid(2)
    if i < Volc.shape[0] and j < Volc.shape[1]:
        v = Volc[i, j]
        if v > 1.0:
            Volc[i, j] = 1.0
        elif v < -1.0:
            Volc[i, j] = -1.0


@cuda.jit
def k_collide_V(f, feq, omegaV, F, Volc, eff_fac, dt):
    """Fused BGK collision + force + volcanic source for the velocity LB.
    VSource = eff_fac*Volc/dt computed inline."""
    i, j = cuda.grid(2)
    if i < omegaV.shape[0] and j < omegaV.shape[1]:
        om = omegaV[i, j]
        vs = dt * 0.5 * (eff_fac * Volc[i, j] / dt)
        for k in range(9):
            f[k, i, j] = (1.0 - om) * f[k, i, j] + om * feq[k, i, j] + F[k, i, j] + vs


@cuda.jit
def k_stream(f_in, f_out):
    """Pull-scheme streaming with periodic wrap for all 9 directions.
    Matches the (i±1) % (n+1) indexing of the CPU kernels (shared by the
    f and g fields). f_out must be a distinct buffer."""
    i, j = cuda.grid(2)
    N = f_in.shape[1]   # n+1
    M = f_in.shape[2]   # m+1
    if i < N and j < M:
        im1 = (i - 1) % N
        ip1 = (i + 1) % N
        jm1 = (j - 1) % M
        jp1 = (j + 1) % M
        f_out[0, i, j] = f_in[0, i, j]
        f_out[1, i, j] = f_in[1, im1, j]
        f_out[2, i, j] = f_in[2, i, jm1]
        f_out[3, i, j] = f_in[3, ip1, j]
        f_out[4, i, j] = f_in[4, i, jp1]
        f_out[5, i, j] = f_in[5, im1, jm1]
        f_out[6, i, j] = f_in[6, ip1, jm1]
        f_out[7, i, j] = f_in[7, ip1, jp1]
        f_out[8, i, j] = f_in[8, im1, jp1]


@cuda.jit
def k_bc_V_lr(f):
    """Bounce-back at left (i=0) and right (i=n) walls."""
    j = cuda.grid(1)
    n = f.shape[1] - 1
    if j < f.shape[2]:
        # Left/West i=0
        f[1, 0, j] = f[3, 0, j]
        f[5, 0, j] = f[6, 0, j]
        f[8, 0, j] = f[7, 0, j]
        # Right/East i=n
        f[3, n, j] = f[1, n, j]
        f[6, n, j] = f[5, n, j]
        f[7, n, j] = f[8, n, j]


@cuda.jit
def k_bc_V_tb(f):
    """Bounce-back at bottom (j=0), free-slip mirror at top (j=m).
    Launched AFTER k_bc_V_lr so corner nodes match CPU ordering."""
    i = cuda.grid(1)
    m = f.shape[2] - 1
    if i < f.shape[1]:
        # Bottom j=0
        f[2, i, 0] = f[4, i, 0]
        f[5, i, 0] = f[8, i, 0]
        f[6, i, 0] = f[7, i, 0]
        # Top j=m - free slip
        f[4, i, m] = f[2, i, m]
        f[7, i, m] = f[6, i, m]
        f[8, i, m] = f[5, i, m]


@cuda.jit
def k_macro_V(f, cx, cy, rho, vx, vy):
    """Macroscopic density and velocity."""
    i, j = cuda.grid(2)
    if i < rho.shape[0] and j < rho.shape[1]:
        r = 0.0
        u = 0.0
        v = 0.0
        for k in range(9):
            fk = f[k, i, j]
            r += fk
            u += fk * cx[k]
            v += fk * cy[k]
        rho[i, j] = r
        vx[i, j] = u / r
        vy[i, j] = v / r


@cuda.jit
def k_fneq(f, feq, fneq):
    """fneq = f - feq (post-stream f minus pre-collision feq, as in the
    CPU LB_D2Q9_V)."""
    i, j = cuda.grid(2)
    if i < f.shape[1] and j < f.shape[2]:
        for k in range(9):
            fneq[k, i, j] = f[k, i, j] - feq[k, i, j]


# ------------------------------------------------------------------ #
# Thermal (g) field kernels
# ------------------------------------------------------------------ #
@cuda.jit
def k_geq(w, cx, cy, th, vx, vy, geq):
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        for k in range(9):
            geq[k, i, j] = w[k] * th[i, j] * (1.0 + 3.0 * (vx[i, j] * cx[k] + vy[i, j] * cy[k]))


@cuda.jit
def k_source_T(th, Tmagma, Volc, Depl, C, dens, x_Ts, x_Tl, Y, Cp, dt,
               prefac_D, prefac_V, sink_prefac, dT1, dT2, Sink):
    """Elementwise port of the depletion-refrigeration / volcanic-heating /
    sink algebra from LB_D2Q9_T, including the depth-zone filters."""
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        T = th[i, j]
        # --- Depletion effect (refrigeration) ---
        d1 = 0.0
        dT_D = T - x_Ts[i, j]
        vfilt1 = (-1.0 * Depl[i, j]) < C[i, j]
        if dT_D < 0.0:
            dT_D = 0.0
        if not vfilt1:
            dT_D = 0.0
        mass_D = 0.0
        if vfilt1:
            mass_D = abs(Depl[i, j] - C[i, j]) * dens[i, j]
        if mass_D > 0.0:
            J2 = Cp * mass_D * dT_D
            d1 = -1.0 * abs(J2 / (mass_D * Cp + 1e-9)) * (1.0 / dt)
        d1 = d1 * prefac_D

        # --- Volcanic heating ---
        d2 = 0.0
        dT = Tmagma[i, j] - T
        if dT < 0.0:
            dT = 0.0
        if T > x_Tl[i, j]:
            dT = 0.0
        mass = Volc[i, j] * dens[i, j]
        if mass > 0.0:
            J1 = Cp * mass * dT
            d2 = abs(J1 / (mass * Cp)) * (1.0 / dt)
        d2 = d2 * prefac_V
        if mass == 0.0:
            d2 = 0.0

        # --- Runaway-thermal sink ---
        s = 0.0
        if T > x_Tl[i, j]:
            s = sink_prefac

        # --- Depth-zone filters (order matters: d1 first, then d2) ---
        yv = Y[i, j]
        if (yv > 0.981) and (d2 > 0.0):
            d1 = 0.0
        if yv > 0.99:
            d1 = 0.0
        if (yv < 0.969) and (d1 < 0.0):
            d2 = 0.0

        dT1[i, j] = d1
        dT2[i, j] = d2
        Sink[i, j] = s


@cuda.jit
def k_collide_T(g, geq, omegaT, dt, H, dT1, dT2, Sink):
    i, j = cuda.grid(2)
    if i < H.shape[0] and j < H.shape[1]:
        src = dt * 0.5 * H[i, j] + dt * 0.5 * dT1[i, j] + dt * 0.5 * dT2[i, j] - Sink[i, j]
        for k in range(9):
            g[k, i, j] = (1.0 - omegaT) * g[k, i, j] + omegaT * geq[k, i, j] + src


@cuda.jit
def k_bc_T_lr(g):
    """Adiabatic side walls: copy full population column from i=1 / i=n-1."""
    j = cuda.grid(1)
    n = g.shape[1] - 1
    if j < g.shape[2]:
        for k in range(9):
            g[k, 0, j] = g[k, 1, j]
            g[k, n, j] = g[k, n - 1, j]


@cuda.jit
def k_bc_T_tb(g, w, T_top, T_base):
    """Fixed-temperature top/bottom (anti-bounce-back style).
    Launched AFTER k_bc_T_lr so corners match CPU ordering."""
    i = cuda.grid(1)
    m = g.shape[2] - 1
    if i < g.shape[1]:
        # Bottom j=0 - fixed T_base
        g[6, i, 0] = w[6] * T_base + w[8] * T_base - g[8, i, 0]
        g[5, i, 0] = w[5] * T_base + w[7] * T_base - g[7, i, 0]
        g[2, i, 0] = w[2] * T_base + w[4] * T_base - g[4, i, 0]
        # Top j=m - fixed T_top
        g[7, i, m] = w[7] * T_top + w[5] * T_top - g[5, i, m]
        g[4, i, m] = w[4] * T_top + w[2] * T_top - g[2, i, m]
        g[8, i, m] = w[8] * T_top + w[6] * T_top - g[6, i, m]


@cuda.jit
def k_macro_T(g, th):
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        s = 0.0
        for k in range(9):
            s += g[k, i, j]
        th[i, j] = s


# ------------------------------------------------------------------ #
# Viscosity / plasticity kernel
# ------------------------------------------------------------------ #
@cuda.jit
def k_visc(th, omegaV, visc, fneq, rho, cx, cy, Y, minmax_th,
           T_top, T_base, visc_cut, visc_scale, high_stress_visc, N_exp,
           alpha, m_lat, shear_strain_out,
           delta_eta, C0_MS98, tau1_MS98, depth_scale):
    """Port of _solve_visc_kernel. All physics constants (delta_eta,
    C0_MS98, tau1_MS98, depth_scale) are now passed from the driver; none
    are hard-coded here. depth_scale is the (1-Y)*depth_scale factor in
    the yield law (was the literal 300). m_lat is the lattice length L
    used in the stress conversion (driver should pass m-1 to match the CPU
    kernel's m1)."""
    i, j = cuda.grid(2)
    if i < th.shape[0] and j < th.shape[1]:
        theta = math.log(delta_eta)

        # v0 pins the hot base (T=T_base) to visc_scale; fixed normalization
        vmin = math.exp(-theta * T_base)
        v0 = visc_scale / vmin
        # Local FK viscosity
        tmp = th[i, j]
        if tmp < T_top:
            tmp = T_top
        if tmp > T_base:
            tmp = T_base
        vT = math.exp(-theta * tmp) * v0
        if vT > visc_cut:
            vT = visc_cut

        # Deviatoric stress from fneq moments
        fm = m_lat
        v_l_K_l_over_L_l3 = visc_scale * alpha / (fm * fm * fm)
        v_k_K_l_over_L_l2 = visc_scale * alpha / (fm * fm)
        tau1_l = tau1_MS98 * v_l_K_l_over_L_l3
        C0_l = C0_MS98 * v_k_K_l_over_L_l2

        S_prefac = 3.0 * omegaV[i, j] / (2.0 * rho[i, j])
        Sxx = 0.0
        Syy = 0.0
        Sxy = 0.0
        for k in range(9):
            fk = fneq[k, i, j]
            Sxx += fk * cx[k] * cx[k]
            Syy += fk * cy[k] * cy[k]
            Sxy += fk * cx[k] * cy[k]
        I1 = Sxx + Syy
        I2 = Sxx * Syy - Sxy * Sxy
        J2 = abs((I1 * I1) / 3.0 - I2)
        eff_stress = math.sqrt(3.0 * J2)
        ss = abs(eff_stress * S_prefac)
        shear_strain_out[i, j] = ss

        ys = C0_l + tau1_l * ((1.0 - Y[i, j]) * depth_scale)
        stress = vT * ss
        if (stress >= ys):
            vp = (ys / ss) ** N_exp
            if vp < high_stress_visc:
                vp = high_stress_visc
            visc[i, j] = vp
        else:
            visc[i, j] = vT
        omegaV[i, j] = 1.0 / (3.0 * visc[i, j] + 0.5)


# ------------------------------------------------------------------ #
# Physics parameter container
# ------------------------------------------------------------------ #
class PhysParams:
    """Single source of truth for every physics constant the kernels need.
    Built ONCE in the driver and handed to DeviceState; kernels receive
    only plain floats unpacked from here. No physics constant is hard-coded
    inside any kernel. To add a constant later: add a field here, pass it
    from the driver, and add it to the relevant kernel launch + signature.

    Fields (all lattice/dimensionless unless noted):
      eff_fac       volcanic velocity-source efficiency  (was 5e-4)
      gbeta10       compositional buoyancy coefficient    (was 0.0)
      cdens_ref     compositional density reference [kg/m^3] (was 2900)
      cdens_span    compositional density span      [kg/m^3] (was 3400-2900=500)
      prefac_D      depletion-refrigeration efficiency    (was 1e-4)
      prefac_V      volcanic-heating efficiency           (was 1e-4)
      sink_prefac   runaway-thermal sink prefactor        (was 0.0)
      delta_eta     FK total viscosity contrast           (was 3e4)
      C0_MS98       cohesion yield stress (MS98 units)     (was 1e5)
      tau1_MS98     yield-stress depth gradient (MS98)     (was 1e7)
      depth_scale   depth factor in yield law             (was 300)
      L_lat         lattice length in stress conversion   (was m; should be m-1)
    """
    def __init__(self,
                 eff_fac=5e-4, gbeta10=0.0,
                 cdens_ref=2900.0, cdens_span=500.0,
                 prefac_D=1e-4, prefac_V=1e-4, sink_prefac=0.0,
                 delta_eta=3e4, C0_MS98=1e5, tau1_MS98=1e7,
                 depth_scale=300.0, L_lat=None):
        self.eff_fac = float(eff_fac)
        self.gbeta10 = float(gbeta10)
        self.cdens_ref = float(cdens_ref)
        self.cdens_span = float(cdens_span)
        self.prefac_D = float(prefac_D)
        self.prefac_V = float(prefac_V)
        self.sink_prefac = float(sink_prefac)
        self.delta_eta = float(delta_eta)
        self.C0_MS98 = float(C0_MS98)
        self.tau1_MS98 = float(tau1_MS98)
        self.depth_scale = float(depth_scale)
        self.L_lat = L_lat  # set by DeviceState to m-1 if left None


# ------------------------------------------------------------------ #
# Device state container + one full timestep
# ------------------------------------------------------------------ #
class DeviceState:
    """Holds all device-resident arrays and launch configs, and provides
    step_V / step_T / step_visc mirroring the CPU LB_D2Q9_V / LB_D2Q9_T /
    solve_viscosity call sequence."""

    def __init__(self, n, m, f, g, feq, geq, rho, vx, vy, th, dens, visc,
                 omegaV, Volc, Tmagma, Depl, C, H, x_Ts, x_Tl, Y, w, cx, cy,
                 params=None):
        self.n, self.m = n, m
        self.g2 = grid2d(n, m)
        self.b1_j = grid1d(m + 1)
        self.b1_i = grid1d(n + 1)

        # Physics parameters: single source of truth. If none supplied, use
        # the documented defaults (which reproduce the previous hard-coded
        # values). L_lat defaults to m-1 to match the CPU kernel's m1.
        self.p = params if params is not None else PhysParams()
        if self.p.L_lat is None:
            self.p.L_lat = float(m - 1)

        to_dev = cuda.to_device
        self.f = to_dev(np.ascontiguousarray(f))
        self.ftmp = cuda.device_array_like(self.f)
        self.g = to_dev(np.ascontiguousarray(g))
        self.gtmp = cuda.device_array_like(self.g)
        self.feq = to_dev(np.ascontiguousarray(feq))
        self.geq = to_dev(np.ascontiguousarray(geq))
        self.fneq = cuda.device_array_like(self.f)
        self.F = cuda.device_array_like(self.f)

        self.rho = to_dev(np.ascontiguousarray(rho))
        self.vx = to_dev(np.ascontiguousarray(vx))
        self.vy = to_dev(np.ascontiguousarray(vy))
        self.th = to_dev(np.ascontiguousarray(th))
        self.dens = to_dev(np.ascontiguousarray(dens))
        self.visc = to_dev(np.ascontiguousarray(visc))
        self.omegaV = to_dev(np.ascontiguousarray(omegaV))
        self.shear_strain = cuda.device_array_like(self.th)

        self.Volc = to_dev(np.ascontiguousarray(Volc))
        self.Tmagma = to_dev(np.ascontiguousarray(Tmagma))
        self.Depl = to_dev(np.ascontiguousarray(Depl))
        self.C = to_dev(np.ascontiguousarray(C))
        self.H = to_dev(np.ascontiguousarray(H))
        self.x_Ts = to_dev(np.ascontiguousarray(x_Ts))
        self.x_Tl = to_dev(np.ascontiguousarray(x_Tl))
        self.Y = to_dev(np.ascontiguousarray(Y))
        self.dT1 = cuda.device_array_like(self.th)
        self.dT2 = cuda.device_array_like(self.th)
        self.Sink = cuda.device_array_like(self.th)

        self.w = to_dev(np.ascontiguousarray(w))
        self.cx = to_dev(np.ascontiguousarray(cx))
        self.cy = to_dev(np.ascontiguousarray(cy))

        self.minmax_th = cuda.device_array(2, dtype=np.float64)
        self._mm_reset = np.array([np.inf, -np.inf], dtype=np.float64)

    # -- reductions -------------------------------------------------- #
    def update_minmax_th(self):
        self.minmax_th.copy_to_device(self._mm_reset)
        k_minmax[self.g2, TPB2D](self.th, self.minmax_th)

    # -- one velocity-LB step (== LB_D2Q9_V) ------------------------- #
    def step_V(self, gbeta, dt):
        d = self
        p = self.p
        k_force[d.g2, TPB2D](d.w, d.cx, d.cy, gbeta, p.gbeta10, d.th,
                             d.minmax_th, d.dens, d.rho, d.F,
                             p.cdens_ref, p.cdens_span)
        k_feq[d.g2, TPB2D](d.vx, d.vy, d.cx, d.cy, d.rho, d.w, d.feq)
        k_fneq[d.g2, TPB2D](d.f, d.feq, d.fneq)
        k_clamp_volc[d.g2, TPB2D](d.Volc)
        k_collide_V[d.g2, TPB2D](d.f, d.feq, d.omegaV, d.F, d.Volc, p.eff_fac, dt)
        k_stream[d.g2, TPB2D](d.f, d.ftmp)
        d.f, d.ftmp = d.ftmp, d.f
        k_bc_V_lr[d.b1_j, TPB1D](d.f)
        k_bc_V_tb[d.b1_i, TPB1D](d.f)
        k_macro_V[d.g2, TPB2D](d.f, d.cx, d.cy, d.rho, d.vx, d.vy)


    # -- one thermal-LB step (== LB_D2Q9_T) -------------------------- #
    def step_T(self, omegaT, dt, Cp, T_top, T_base):
        d = self
        p = self.p
        k_geq[d.g2, TPB2D](d.w, d.cx, d.cy, d.th, d.vx, d.vy, d.geq)
        k_source_T[d.g2, TPB2D](d.th, d.Tmagma, d.Volc, d.Depl, d.C, d.dens,
                                d.x_Ts, d.x_Tl, d.Y, Cp, dt,
                                p.prefac_D, p.prefac_V, p.sink_prefac,
                                d.dT1, d.dT2, d.Sink)
        k_collide_T[d.g2, TPB2D](d.g, d.geq, omegaT, dt, d.H, d.dT1, d.dT2, d.Sink)
        k_stream[d.g2, TPB2D](d.g, d.gtmp)
        d.g, d.gtmp = d.gtmp, d.g
        k_bc_T_lr[d.b1_j, TPB1D](d.g)
        k_bc_T_tb[d.b1_i, TPB1D](d.g, d.w, T_top, T_base)
        k_macro_T[d.g2, TPB2D](d.g, d.th)

    # -- viscosity update (== solve_viscosity) ----------------------- #
    def step_visc(self, T_top, T_base, visc_cut, visc_scale,
                  high_stress_visc, N_exp, alpha):
        d = self
        # th just changed in step_T -> refresh min/max. The same buffer
        # then serves as tref for the NEXT step_V (th is unchanged
        # between here and there), matching the CPU data flow.
        d.update_minmax_th()
        p = self.p
        k_visc[d.g2, TPB2D](d.th, d.omegaV, d.visc, d.fneq, d.rho,
                            d.cx, d.cy, d.Y, d.minmax_th,
                            T_top, T_base, visc_cut, visc_scale,
                            high_stress_visc, N_exp, alpha, p.L_lat,
                            d.shear_strain,
                            p.delta_eta, p.C0_MS98, p.tau1_MS98, p.depth_scale)
