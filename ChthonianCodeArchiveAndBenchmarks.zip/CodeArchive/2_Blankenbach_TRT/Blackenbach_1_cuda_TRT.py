import os
os.environ['NUMBA_NUM_THREADS'] = '10'
os.environ['OMP_NUM_THREADS'] = '10'
os.environ['MKL_NUM_THREADS'] = '10'

import matplotlib
matplotlib.use('Agg')
import pylab as pl
import matplotlib.pyplot as plt
from matplotlib import colormaps
import numpy as np
from numba import jit
from scipy.interpolate import griddata
from scipy.interpolate import interp1d
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from mpl_toolkits.axes_grid1 import make_axes_locatable
from numba import njit, prange, set_num_threads
from lb_cuda_kernels import DeviceState, PhysParams  # GPU port: device-resident LB kernels + params
from scipy.special import erf
import shutil
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')

set_num_threads(8)

# UPDATES
# Includes T-dep visc, and plasticity
# Check volc against Un version


###################### MIT LICENSING ###########################################
#
#
#Copyright 2024 Dr Craig O'Neill
#
#Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the “Software”), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
#
#The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
#
#THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
################################################################################ 

########################################################################################################################################################
# The following is a minimum-requisite and dependency python script to calculate mantle flow field for the Blankenbach ety al. (1989) mantle convection# 
# benchmark.                                                                                                                                           #  
# It still has routines to calculate volcanic heat transport, and transport thermal effects. These have been skipped in this setup though.             #
# The thermal convection solver has been benchmarked using both BGK and TRT schemes *this is the TRT benchmark.    Full implementation is to be       #
# presented in expanded upcoming publications. Please see https://github.com/thecraigoneill/planet_LB for the up to date core code archive.            #
########################################################################################################################################################



# Use 1D melt column routine as basis
# Loop through each column in 2D to calculate
# Initialisation?

# Melt routine - 1D
# Import columns of model seperately.
@jit(nopython=True)
def magma_source_1Dcol(T,C,Y,x_Ts,x_Tl,dx,dt,dens,melt_dens):
    Volume = dx # 1D
    # Get existing depletion as depleted solidus
    Cmod = -1 * np.maximum(C,np.ones_like(C)*(-1))  #Depletion should be tracked as -1 < C < 0. Positive for crust.
    Cmod[Cmod < 0] = 0.0  # Eliminate crust from depleting
    Depl_sol = Cmod * (x_Tl - x_Ts) + x_Ts 
    Depl_melt_frac = (T - Depl_sol)/(x_Tl-x_Ts)
    Depl_melt_frac[Cmod < 0] = 0.0 # Eliminate crustal melting... again.
    #if(np.any(np.isnan(C))):
    #   print("NAN in C")
    #   #exit()

    ###### Melt Fraction ###########################
    #melt_frac = ((T - x_Ts)/(x_Tl - x_Ts)) #As fraction
    #print(melt_frac[melt_frac > 0])
    #melt_frac [melt_frac  < 0] = 0.0
    #melt_frac [melt_frac  > 1] = 1.0
    # Now check against depl, and modify f accordingly
    melt_frac2 = np.copy(Depl_melt_frac) #melt_frac - Depl_old
    melt_frac2[melt_frac2  < 0] = 0.0
    melt_frac2[melt_frac2  > 1] = 1.0
    melt_frac = np.copy(melt_frac2)

    #if(np.any(np.isnan(melt_frac))):
    #   print("NAN in Melt frac")


    #VOLC
    Volc1 = np.copy(melt_frac2)*0.0  # Purely for source region here, not injection yet.
    Depl = np.copy(melt_frac2)
    Depl[C > 0.6] = 0.0
    
    Tmagma = np.zeros_like(Y)
    #dens2 = np.zeros_like(dens)
    devs = np.random.normal(0,50,np.shape(dens))  #This is dimensional
    dens2 = np.copy(dens) + devs
    done=0
    gamma = np.random.gamma(1,1,np.shape(Volc1))
    melt_den = melt_dens + (-150.0*gamma) + 80  #This is dimensionalised
    melt_den[melt_frac == 0] = 0.0

    Volc2 = np.copy(Volc1[:])  #Note arrays get tranposed when plotted.
    dens2a = np.copy(dens2)
    T1 = np.copy(T[:])
    Tmagma1 = np.copy(Tmagma[:])
    melt_den1 = np.copy(melt_den[:])



    for i in range(len(Volc1)):
        # Need to propagate up from melt depth/density to surface
        # Note in 2D Y[:,0]: 0->1
        #            dens: 2900 -> 3400
        #            melt_dens -> surface-> base
        if( (melt_frac[i] > 0.0)&( (C[i]>=-1)&(C[i]<0.6)) ):   #Limit melt transport to fertile mantle
            dens_col = (dens2a[i:]) #[::-1] # density array from melt depth upwards 
            y = Y[i:]
            done=0
            kk=0 #
            #print("Melt:",melt_frac[i],Y,dens_col,melt_den1[i])
            for j in range(len(dens_col)): #Includes last index. Bottom up search. 
              #print("Melting:",i,j,kk,Y[i],y[j],melt_frac[i],melt_den1[i],dens_col[j])
              if ((done == 0) & (melt_den1[i] > dens_col[j])): #Emplaced at neutral buoyancy
                done=1
                kk=j
                #print(kk)
              elif((done==0)&(j==(len(dens_col))-1 )):  #Erupted at surface
                kk=j-1
                done=1
                #print("2:",kk)

            if (kk>0):
                ii = i + kk # Reconstruct initial index
                Volc2[ii] += (melt_frac[i]) #THis should invert Volc again to +ve
                Tmagma1[ii] = T1[i]
                #print(i,kk,ii,"Depths melt/emplacemnt:",Y[i],Y[ii],"Melt/volc:",melt_frac[i],Volc2[ii],"C",C[i],"Depl",Depl[i],"Dens melt/crust:",melt_den1[i],dens2a[ii])

    Volc1 = np.copy(Volc2)
    #print("Melt",melt_frac,"Volc:",Volc1,"Depl:",Depl)
    #print("VOLC:",Volc)
    dens2 = dens2a      
    #T[k,:] = T1      
    Tmagma = np.copy(Tmagma1) 
    melt_den = melt_den1
    #print("VOLC",Volc[0:10,0:10],"Tmagma",Tmagma[0:10,0:10],"is nan?",np.isnan(Volc),np.isnan(Tmagma))

    if(np.any(np.isnan(Volc1))):
       #print("NAN in Volc")
       Volc1[np.isnan(Volc1)] = 0.0
    if(np.any(np.isnan(Tmagma))):
       #print("NAN in Tmagma")
       Tmagma[np.isnan(Tmagma)] = 0.0
    Tmagma[-1] = 0.0
    #Volc[-1] = 0

    #print("AMI here",np.shape(Volc1),np.shape(Depl))
    return melt_frac, Volc1, Depl, Tmagma

@jit(nopython=True, parallel=True)
def loop_over_melt_columns(th,C,Y,x_Ts,x_Tl,dx,dt,dens,melt_dens):
    melt_frac = np.zeros_like(Y)
    melt_den = np.ones_like(Y)*melt_dens
    Depl = np.zeros_like(Y)
    Volc = np.zeros_like(Y)
    Tmagma = np.zeros_like(Y)
    for k in prange(len(Volc[:,0])):
        dens2 = dens[k,:]
        C2 = C[k,:]
        Y2 = Y[k,:]
        #T12 = np.copy(th[k,:])
        Ts2 = np.copy(x_Ts[k,:])
        T2 = np.copy(th[k,:])
        Tl2 = np.copy(x_Tl[k,:])
        melt_den2 = melt_den[k,:]
        #print("SHAPE1",np.shape(Volc[k,:]),np.shape(melt_den2))
        melt_frac[k,:], Volc[k,:], Depl[k,:], Tmagma[k,:] =  magma_source_1Dcol(T2,C2,Y2,Ts2,Tl2,dx,dt,dens2,melt_den2)
    return  melt_frac, Volc, Depl, Tmagma




@njit(parallel=True)
def loopy_loop(n,m,vx,vy,cx,cy,rho,w,feq):
    for i in prange(0,n+1):
        for j in range(0,m+1):
            t1 = vx[i,j]*vx[i,j] + vy[i,j]*vy[i,j]
            for k in range(0,9):
                t2 = vx[i,j]*cx[k] + vy[i,j]*cy[k]
                feq[k,i,j] = rho[i,j]*w[k]* (1.0+3.0*t2+4.50*t2*t2-1.50*t1)
    return feq

@njit(parallel=True)
def _collision_force_V(n, m, f, feq, omegaV, F, VSource, dt, magic):
    """Fused TRT collision step for velocity LB — parallel over grid points.
    Two-relaxation-time: om_plus=omegaV sets viscosity, om_minus from the
    magic parameter (Lambda) stabilizes high-viscosity nodes. Opposite
    pairs for this D2Q9 ordering: 0<->0, 1<->3, 2<->4, 5<->7, 6<->8.
    Reduces to BGK when magic=(1/om-0.5)**2."""
    opp = np.array([0,3,4,1,2,7,8,5,6])
    for i in prange(n+1):
        for j in range(m+1):
            om_p = omegaV[i,j]
            tpm = 1.0/om_p - 0.5
            om_m = 1.0/(magic/tpm + 0.5)
            src = F[:,i,j] + dt*0.5*VSource[i,j]  # per-k force + source
            # rest population k=0
            f0 = f[0,i,j]
            fnew0 = f0 - om_p*(f0 - feq[0,i,j])
            # pairs
            new = np.empty(9)
            new[0] = fnew0
            for (a,b) in [(1,3),(2,4),(5,7),(6,8)]:
                fa=f[a,i,j]; fb=f[b,i,j]
                ea=feq[a,i,j]; eb=feq[b,i,j]
                sp=0.5*(fa+fb); sm=0.5*(fa-fb)
                ep=0.5*(ea+eb); em=0.5*(ea-eb)
                rp=om_p*(sp-ep); rm=om_m*(sm-em)
                new[a]=fa-rp-rm
                new[b]=fb-rp+rm
            for k in range(9):
                f[k,i,j] = new[k] + F[k,i,j] + dt*0.5*VSource[i,j]

@njit(parallel=True)
def _compute_force(n, m, w, cx, cy, gbeta, gbeta10, th, tref, cdens, rho, F):
    """Compute gravity force term — parallel over grid points."""
    for i in prange(n+1):
        for j in range(m+1):
            buoy = gbeta * (th[i,j] - tref) * rho[i,j]
            cbuoy = gbeta10 * cdens[i,j] * rho[i,j]
            for k in range(9):
                F[k,i,j] = 3.0 * w[k] * cy[k] * (buoy + cbuoy)

@njit(parallel=True)
def _stream_and_macro_V(n, m, f, cx, cy, rho, vx, vy):
    """Fused streaming + bounce-back BCs + macroscopic vars — parallel."""
    # Streaming into temporary buffer to avoid read-write conflicts
    ftmp = np.empty_like(f)
    # Direction 0: no movement
    for i in prange(n+1):
        for j in range(m+1):
            ftmp[0,i,j] = f[0,i,j]
    # Direction 1: (+1, 0)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i - 1) % (n+1)
            ftmp[1,i,j] = f[1,ip,j]
    # Direction 2: (0, +1)
    for i in prange(n+1):
        for j in range(m+1):
            jp = (j - 1) % (m+1)
            ftmp[2,i,j] = f[2,i,jp]
    # Direction 3: (-1, 0)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i + 1) % (n+1)
            ftmp[3,i,j] = f[3,ip,j]
    # Direction 4: (0, -1)
    for i in prange(n+1):
        for j in range(m+1):
            jp = (j + 1) % (m+1)
            ftmp[4,i,j] = f[4,i,jp]
    # Direction 5: (+1, +1)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i - 1) % (n+1)
            jp = (j - 1) % (m+1)
            ftmp[5,i,j] = f[5,ip,jp]
    # Direction 6: (-1, +1)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i + 1) % (n+1)
            jp = (j - 1) % (m+1)
            ftmp[6,i,j] = f[6,ip,jp]
    # Direction 7: (-1, -1)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i + 1) % (n+1)
            jp = (j + 1) % (m+1)
            ftmp[7,i,j] = f[7,ip,jp]
    # Direction 8: (+1, -1)
    for i in prange(n+1):
        for j in range(m+1):
            ip = (i - 1) % (n+1)
            jp = (j + 1) % (m+1)
            ftmp[8,i,j] = f[8,ip,jp]
    # Copy back
    for k in range(9):
        for i in prange(n+1):
            for j in range(m+1):
                f[k,i,j] = ftmp[k,i,j]
    # Bounce back BCs
    # Left/West i=0
    for j in range(m+1):
        f[1,0,j] = f[3,0,j]
        f[5,0,j] = f[6,0,j]
        f[8,0,j] = f[7,0,j]
    # Right/East i=n
    for j in range(m+1):
        f[3,n,j] = f[1,n,j]
        f[6,n,j] = f[5,n,j]
        f[7,n,j] = f[8,n,j]
    # Bottom j=0
    for i in range(n+1):
        f[2,i,0] = f[4,i,0]
        f[5,i,0] = f[8,i,0]
        f[6,i,0] = f[7,i,0]
    # Top j=m — free slip
    for i in range(n+1):
        f[4,i,m] = f[2,i,m]
        f[7,i,m] = f[6,i,m]
        f[8,i,m] = f[5,i,m]
    # Macroscopic variables
    for i in prange(n+1):
        for j in range(m+1):
            r = 0.0; u = 0.0; v = 0.0
            for k in range(9):
                fk = f[k,i,j]
                r += fk
                u += fk * cx[k]
                v += fk * cy[k]
            rho[i,j] = r
            vx[i,j] = u / r
            vy[i,j] = v / r

# @jit(nopython=True)
def LB_D2Q9_V(dt,m,n,gbeta,cx,cy,omegaV,w,rho,th,vx,vy,f,feq,u0, Volc, Tmagma):
    time=0
    tref = (np.min(th) + np.max(th))/2

    # Gravity force term
    F= np.zeros_like(feq)
    cdens = 0.5 + (2900 - dens)/(3400 - 2900)
    gbeta10 = 0.0
    _compute_force(n, m, w, cx, cy, gbeta, gbeta10, th, tref, cdens, rho, F)

    #Collision step
    feq = loopy_loop(n,m,vx,vy,cx,cy,rho,w,feq)

    filt4 = Volc>1.0
    Volc[filt4] = 1.0
    filt4 = Volc<-1.0
    Volc[filt4] = -1.0
    eff_fac = 5e-4
    VSource = eff_fac*Volc/dt

    _collision_force_V(n, m, f, feq, omegaV, F, VSource, dt, MAGIC_TRT)
    
    #Streaming step — parallel numba kernel
    _stream_and_macro_V(n, m, f, cx, cy, rho, vx, vy)
    if(np.any(np.isnan(vx))):
       print("NAN in vx")
    if(np.any(np.isnan(vy))):
       print("NAN in vy")
    if(np.any(np.isnan(rho))):
       print("NAN in rho")

    fneq = f - feq
    return rho, vx, vy, f, fneq

@njit(parallel=True)
def _stream_and_macro_T(n, m, g, w, T_top, T_base, th):
    """Fused streaming + thermal BCs + macroscopic T — parallel."""
    gtmp = np.empty_like(g)
    # Same streaming directions as V
    for i in prange(n+1):
        for j in range(m+1):
            gtmp[0,i,j] = g[0,i,j]
            gtmp[1,i,j] = g[1,(i-1)%(n+1),j]
            gtmp[2,i,j] = g[2,i,(j-1)%(m+1)]
            gtmp[3,i,j] = g[3,(i+1)%(n+1),j]
            gtmp[4,i,j] = g[4,i,(j+1)%(m+1)]
            gtmp[5,i,j] = g[5,(i-1)%(n+1),(j-1)%(m+1)]
            gtmp[6,i,j] = g[6,(i+1)%(n+1),(j-1)%(m+1)]
            gtmp[7,i,j] = g[7,(i+1)%(n+1),(j+1)%(m+1)]
            gtmp[8,i,j] = g[8,(i-1)%(n+1),(j+1)%(m+1)]
    # Copy back
    for k in range(9):
        for i in prange(n+1):
            for j in range(m+1):
                g[k,i,j] = gtmp[k,i,j]
    # BCs
    # Left i=0, adiabatic
    for k in range(9):
        for j in range(m+1):
            g[k,0,j] = g[k,1,j]
    # Right i=n, adiabatic
    for k in range(9):
        for j in range(m+1):
            g[k,n,j] = g[k,n-1,j]
    # Bottom j=0 — fixed T_base
    for i in range(n+1):
        g[6,i,0] = w[6]*T_base + w[8]*T_base - g[8,i,0]
        g[5,i,0] = w[5]*T_base + w[7]*T_base - g[7,i,0]
        g[2,i,0] = w[2]*T_base + w[4]*T_base - g[4,i,0]
    # Top j=m — fixed T_top
    for i in range(n+1):
        g[7,i,m] = w[7]*T_top + w[5]*T_top - g[5,i,m]
        g[4,i,m] = w[4]*T_top + w[2]*T_top - g[2,i,m]
        g[8,i,m] = w[8]*T_top + w[6]*T_top - g[6,i,m]
    # Macroscopic temperature
    for i in prange(n+1):
        for j in range(m+1):
            s = 0.0
            for k in range(9):
                s += g[k,i,j]
            th[i,j] = s

@njit(parallel=True)
def _compute_geq(n, m, w, cx, cy, th, vx, vy, geq):
    """Compute thermal equilibrium distribution — parallel over grid points."""
    for i in prange(n+1):
        for j in range(m+1):
            for k in range(9):
                geq[k,i,j] = w[k]*th[i,j]*(1.0+3.0*(vx[i,j]*cx[k]+ vy[i,j]*cy[k]))

@njit(parallel=True)
def _collision_T(n, m, g, geq, omegaT, dt, H, dT1, dT2, Sink):
    """Fused collision step for temperature LB — parallel over grid points."""
    for i in prange(n+1):
        for j in range(m+1):
            for k in range(9):
                g[k,i,j] = (1.0 - omegaT)*g[k,i,j] + omegaT*geq[k,i,j] + dt*0.5*H[i,j] + dt*0.5*dT1[i,j] + dt*0.5*dT2[i,j] - Sink[i,j]

# @jit(nopython=True)
def LB_D2Q9_T(dt,m,n,cx,cy,omegaT,w,T_top,T_base,T,vx,vy,g,geq,H, Volc, Tmagma, x_Ts, Depl, Cp, Y):
    #Collision
    np.set_printoptions(precision=3)
    th=T

    _compute_geq(n, m, w, cx, cy, th, vx, vy, geq)
   


    # Depletion effect - refridgeration
    prefac_D = 1e-4
    dT2 = np.zeros_like(T)
    dT1 = np.copy(dT2)

    dT_D =  (T - x_Ts)  # Temperature above solidus
    vfilt1 = (-1*Depl < C) # Has depletion exceeded previous depletion (as tracked by C)? 
    f3 = dT_D > 0
    dT_D[~f3] = 0.0 #If not above solidus temperature, no depletion (this is a sanity check)
    dT_D[~vfilt1] = 0.0 # If not exceed previous depletion ie. C, no depletion.

    mass_D = np.zeros_like(dT_D)
    mass_D[vfilt1] = np.abs(Depl[vfilt1] - C[vfilt1]) * dens[vfilt1] # Mass of newly depleted material
    J2 = Cp * mass_D * dT_D  # Energy consumed depleting that mass
    fmD = mass_D > 0  #Only consider material depleted
    dT1[fmD] = -1*np.abs( (J2[fmD]/(mass_D[fmD] * Cp + 1e-9) ) ) * 1/dt      # Energy change total
    dT1 *= prefac_D  # Limit by efficiency of melt transfer (assumed 1 here)


    # Now add volc heat terms
    prefac_V = 1e-4
    filT = Tmagma > 0
    dT = Tmagma - T
    dT[dT < 0] = 0.0 #np.maximum((Tmagma[filT] - th[filT]),(x_Ts[filT] - th[filT]))
    filtT2 = T > x_Tl
    dT[filtT2] = 0 # Can't add more heat if at liquidus (here at least)
    mass = Volc * dens # mass of intruded material in kg* B) # Accounts for temperature and volume fraction of melt
    J1 = Cp * mass * dT #Energy added
    fm = mass > 0
    dT2[fm] = np.abs( ( J1[fm]/(mass[fm] * Cp) )) * 1/dt
    dT2 *= prefac_V
    fm2 = (mass == 0)
    dT2[fm2] = 0.0

    # Catch runaway thermals
    sink = T > (x_Tl)
    prefac= 0.0*1e-15
    Sink = np.zeros_like(T)
    Sink[sink] = prefac
   
    # Only interested in mantle melting and crustal volcanic emplacement here. We'll let mantle emplaced 
    # melts do their trippy mixy thing. 
    #12 km == Y=0.981
    # 7km = Y = 0.99
    # 20 km = Y=0.969
    dT1[(Y > 0.981) & (dT2 > 0)] = 0.0  # No depletion of shallow crust, if melting
    dT1[(Y > 0.99)] = 0.0            # No depletion cooling of very shallow crust at all
    dT2[(Y<0.969) & (dT1 < 0)] = 0.0  # No melt heating of mantle, if it is depleting
 

    _collision_T(n, m, g, geq, omegaT, dt, H, dT1, dT2, Sink)


    _stream_and_macro_T(n, m, g, w, T_top, T_base, th)

    if(np.any(np.isnan(th))):
       print("NAN in th")
   
    return th, g

def LB_D2Q9_C(dt,m,n,cx,cy,omegaC,w,th,vx,vy,fc,fceq,C,Volc,dens,rho, Depl):
    #Collision
    np.set_printoptions(precision=3)
    fceq[0,:,:] = w[0]*C*(1.0+3.0*(vx*cx[0]+ vy*cy[0]))
    fceq[1,:,:] = w[1]*C*(1.0+3.0*(vx*cx[1]+ vy*cy[1]))
    fceq[2,:,:] = w[2]*C*(1.0+3.0*(vx*cx[2]+ vy*cy[2]))
    fceq[3,:,:] = w[3]*C*(1.0+3.0*(vx*cx[3]+ vy*cy[3]))
    fceq[4,:,:] = w[4]*C*(1.0+3.0*(vx*cx[4]+ vy*cy[4]))
    fceq[5,:,:] = w[5]*C*(1.0+3.0*(vx*cx[5]+ vy*cy[5]))
    fceq[6,:,:] = w[6]*C*(1.0+3.0*(vx*cx[6]+ vy*cy[6]))
    fceq[7,:,:] = w[7]*C*(1.0+3.0*(vx*cx[7]+ vy*cy[7]))
    fceq[8,:,:] = w[8]*C*(1.0+3.0*(vx*cx[8]+ vy*cy[8]))


    # Chemical terms

    prefacC = 1e-4
    prefac2=0.008 # This are equivalent to efficiency terms, determined heuristically.
    prefac1=0.008 # They have a minor effect against large excursions
    Volc_add = prefac1 * Volc / (dt)
    Depl_loss = prefac2 * Depl/(dt)
    #Depl_loss[Volc > 0] = 0.0  # These conditionals might drive depletion to +ve values
    #Depl_loss[Y > 0.981] = 0.0
    sinkC = C >1.5
    SinkC = np.zeros_like(C)
    SinkC[sinkC] = prefacC 
    sourceC = C <-1
    SourceC = np.zeros_like(C)
    SourceC[sourceC]=prefacC 

    fc = (1.0 - omegaC)*fc + omegaC*fceq +  dt*0.5*Volc_add - dt*0.5*Depl_loss - SinkC + SourceC
    
    #Streaming
    fc[2,:,:] = np.roll(fc[2,:,:],1,axis=1)
    fc[6,:,:] = np.roll(fc[6,:,:],-1,axis=0)
    fc[6,:,:] = np.roll(fc[6,:,:],1,axis=1)
    fc[1,:,:] = np.roll(fc[1,:,:],1,axis=0)
    fc[5,:,:] = np.roll(fc[5,:,:],1,axis=0)
    fc[5,:,:] = np.roll(fc[5,:,:],1,axis=1)
    
    fc[4,:,:] = np.roll(fc[4,:,:],-1,axis=1)
    fc[8,:,:] = np.roll(fc[8,:,:],1,axis=0)
    fc[8,:,:] = np.roll(fc[8,:,:],-1,axis=1)
  
    fc[3,:,:] = np.roll(fc[3,:,:],-1,axis=0)
    fc[7,:,:] = np.roll(fc[7,:,:],-1,axis=0)
    fc[7,:,:] = np.roll(fc[7,:,:],-1,axis=1)
    
    # BCs - As per working Snowy Hydro file
    # Left  i=0, adiabatic  
    #g[:,0,:] = g[:,1,:]
    #LHS - C adiabatic
    fc[:,0,:] = fc[:,1,:]
    # Right,i=n, adiabatic 
    fc[:,n,:] = fc[:,n-1,:]
    # BOTTOM: j=m (inverting top and bottom definitions)
    fc[:,:,0] =  fc[:,:,1] 
    # TOP j=0  
    fc[:,:,m] =  fc[:,:,m-1]

    C = fc[0,:,:] + fc[1,:,:] + fc[2,:,:] + fc[3,:,:] + fc[4,:,:] + fc[5,:,:] + fc[6,:,:]+fc[7,:,:]+fc[8,:,:]

    
    # Update density field dens THIS IS DIMENSIONALISED!
    density_S = [3200,3400, 3050, 2900]
    C_S = [-1, 0, 0.6, 1.0]
    fii = interp1d(C_S,density_S,fill_value=(3200,2900),bounds_error=False)
    dens = fii(C)
    #Eclogite
    f3 = (((Y< 0.95)&(Y>0.9))&( (C>0.7) ) )  
    #dens[f3] = 4092 - 500/(1+ 10**(Y[f3]*2)) #3300 #eclogite
    dens[f3] =  2900 + (3300-2900)/(1+ 10**(( (Y[f3] - 0.925)/(0.95-0.9) )*5.0))
    dens[ (Y<=0.9)&((C>0.7)) ] = 3300 # Full eclogite
    if(np.any(np.isnan(C))):
       print("NAN in C")
    if(np.any(np.isnan(dens))):
       print("NAN in dens")


    return C, dens, fc

def export_pic2(l,th,vx,vy,X,Y,XL,YL,C,dens,Volc,Depl,melt_frac,shear_strain,visc,dir_out):
    # Regular unit-square grid: sample by index instead of griddata (orders of magnitude faster)
    nn_g = vx.shape[0]-1
    mm_g = vx.shape[1]-1
    ix = np.rint(XL*nn_g).astype(np.int64)
    iy = np.rint(YL*mm_g).astype(np.int64)
    vxL = vx[ix, iy]
    vyL = vy[ix, iy]
    vmag = np.sqrt(vxL*vxL + vyL*vyL)

    fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(18,5), dpi=150)
    title="timestep = "+str(l)
    nn = th.shape[0]-1
    mm = th.shape[1]-1

    # Temperature + velocity — pinned colorbar 0->1
    con1 = ax1.contour(X,Y,th,5,colors='black',alpha=0.3,linewidth=0.2)
    ax1.clabel(con1,inline=True,fontsize=8)
    ax1.set_ylabel("Y")
    ax1.set_xlabel("X")
    ax1.set_title(title)
    im=ax1.imshow(th.T, extent=[0, 1, 0, 1], origin='lower', cmap='inferno', alpha=0.5, vmin=0.0, vmax=1.0)
    div1=make_axes_locatable(ax1)
    cax1 = div1.append_axes("right", size="5%", pad=0.5)
    cbar=plt.colorbar(im,cax=cax1,label='T',fraction=0.046, pad=0.04)
    cax1.invert_yaxis()
    ax1.set_aspect('auto')
    ax1.quiver(XL, YL, vxL, vyL, vmag, alpha=1.,cmap='magma_r')

    # Log shear strain — pinned colorbar -11 to -2
    ax2.set_ylabel("Y")
    ax2.set_xlabel("X")
    ax2.set_title(title)
    im2 = ax2.imshow(np.log10(np.maximum(shear_strain.T,1e-12)), extent=[0, 1, 0, 1], origin='lower', cmap='magma', alpha=0.99, vmin=-11, vmax=-2)
    div2=make_axes_locatable(ax2)
    cax2 = div2.append_axes("right", size="5%", pad=0.5)
    cbar2=plt.colorbar(im2,cax=cax2,label='log SS',fraction=0.046, pad=0.04)

    # Log viscosity — pinned colorbar -2 to 6
    ax3.set_ylabel("Y")
    ax3.set_xlabel("X")
    ax3.set_title(title)
    im3 = ax3.imshow(np.log10(np.maximum(visc.T,1e-3)), extent=[0, 1, 0, 1], origin='lower', cmap='Spectral', alpha=0.99, vmin=-4, vmax=4)
    div3=make_axes_locatable(ax3)
    cax3 = div3.append_axes("right", size="5%", pad=0.5)
    cbar3=plt.colorbar(im3,cax=cax3,label='log Visc',fraction=0.046, pad=0.04)

    fig.tight_layout()
    str1=str("{:05.0f}".format(l))
    filenm = dir_out+"/impact23_"+str1+".png"
    fig.savefig(filenm)
    plt.close(fig)

def export_pic(l,th,vx,vy,X,Y,XL,YL,C,dens,Volc,Depl,melt_frac,shear_strain,visc,dir_out):
    plt.figure(figsize=(14,6))
    plt.rcParams["figure.dpi"]=300

    vxL = griddata((X.ravel(),Y.ravel()), vx.ravel(), (XL.ravel(),YL.ravel()), method='cubic')
    vyL = griddata((X.ravel(),Y.ravel()), vy.ravel(), (XL.ravel(),YL.ravel()), method='cubic')
    vxL = vxL.reshape(XL.shape)
    vyL = vyL.reshape(XL.shape)

    vmag =np.sqrt(vxL*vxL + vyL*vyL)
    conL = np.array([0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0])

    vmagH =np.sqrt(vx*vx + vy*vy)

    plt.clf()
    plt.figure(figsize=(14,6))
    plt.rcParams["figure.dpi"]=300
    title="timestep = "+str(l)

    ax1=plt.subplot(3,2,1)
    con1 = ax1.contour(X,Y,th,5,colors='black',alpha=0.3,linewidth=0.2)
    ax1.clabel(con1,inline=True,fontsize=8)
    ax1.set_ylabel("Y")
    ax1.set_xlabel("X")
    ax1.set_title(title)
    im=ax1.imshow(th.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='inferno', alpha=0.5)
    div1=make_axes_locatable(ax1)
    cax1 = div1.append_axes("right", size="5%", pad=0.5)
    cbar=plt.colorbar(im,cax=cax1,label='T',fraction=0.046, pad=0.04);
    cax1.invert_yaxis() 
    #ax1.set_aspect('auto')
    q1 = ax1.quiver(XL, YL, vxL, vyL, vmag, alpha=1.,cmap = 'magma_r')
    ax1.set_aspect('auto')
    
    ax2=plt.subplot(3,2,2)
    ax2.set_ylabel("Y")
    ax2.set_xlabel("X")
    ax2.set_title(title)
    #im2=ax2.imshow(vmagH.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='RdGy_r', alpha=0.5)
    #im2=ax2.imshow(Volc.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='RdGy_r', alpha=0.5)
    conL = np.array([0.1,0.2,0.4,0.6,0.8,1.0,1.2])
    cmap1=colormaps.get_cmap('RdGy_r')
    cmap2 = colormaps.get_cmap('cool_r')
    cmap3 = colormaps.get_cmap('plasma')

    cmap2._init() # create the _lut array, with rgba values
    cmap3._init()
    alphas = np.linspace(0, 0.8, cmap2.N+3)
    alphas2 = np.linspace(0, 0.8, cmap3.N+3)

    cmap2._lut[:,-1] = alphas
    cmap3._lut[:,-1] = alphas2

    img2 = ax2.imshow(Depl.T,  interpolation='nearest', extent=[0, n*dx, 0, m*dy], cmap=cmap1, origin='lower',alpha=1.0)
    img3 = ax2.imshow(Volc.T,  interpolation='nearest', extent=[0, n*dx, 0, m*dy], cmap=cmap2, origin='lower',vmin=0.0,vmax=np.mean(0)+2*np.std(Volc))
    img4  = ax2.imshow(melt_frac.T,  interpolation='nearest', extent=[0, n*dx, 0, m*dy], cmap=cmap3, origin='lower')
    #con1 = ax2.contour(X,Y,th,conL,colors='black',alpha=0.3,linewidth=0.3)
    #ax2.clabel(con1,inline=True,fontsize=8)

    div2=make_axes_locatable(ax2)
    cax2 = div2.append_axes("right", size="5%", pad=0.5)
    cbar2=plt.colorbar(img2,cax=cax2,label='Depl/(Volc)',fraction=0.026, pad=0.02);
    #cbar2a=plt.colorbar(img3,cax=cax2,label='Volc',fraction=0.026, pad=0.02);

    #q1 = ax2.quiver(XL, YL, vxL, vyL, vmag, alpha=1.,cmap = 'magma_r')

    ax3=plt.subplot(3,2,3)
    ax3.set_ylabel("Y")
    ax3.set_xlabel("X")
    ax3.set_title(title)
    if (np.max(C) > 2000):
        Clim1 = 2
    else:
        Clim1=np.max(C)
    if (np.min(C) < -20000):
        Clim2 = -2
    else:
        Clim2=np.min(C)
    conL = np.array([-1.0,-0.5,-0.1,-0.05, 0.0, 0.05, 0.1,0.25,0.5,1.0])
    #con3 = ax3.contour(X,Y,C,conL,colors='black',alpha=0.3,linewidth=0.5)
    #ax3.clabel(con3,inline=True,fontsize=8)

    if (Clim1 >= 2000):
        im3 = ax3.imshow(C.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='magma', alpha=0.99,vmin=Clim2,vmax=Clim1)
    else:
        im3 = ax3.imshow(C.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='magma', alpha=0.99,vmin=np.mean(0)-2*np.std(C),vmax=np.mean(0)+2*np.std(C))
    div3=make_axes_locatable(ax3)
    cax3 = div3.append_axes("right", size="5%", pad=0.5)
    cbar3=plt.colorbar(im3,cax=cax3,label='C',fraction=0.046, pad=0.04);
    #q1 = plt.quiver(XL, YL, vxL, vyL, vmag, alpha=1.,cmap = 'magma_r')

    ax4=plt.subplot(3,2,4)
    ax4.set_ylabel("Y")
    ax4.set_xlabel("X")
    ax4.set_title(title)
    fmax=3400
    fmin=2600
    #print("Dens",dens[100,100])
    #import seaborn as sns
    # cmap =  sns.diverging_palette(0,5,s=75,l=50,center="dark",as_cmap=True)
 
    #con4 = ax4.contour(X,Y,dens,10,colors='black',alpha=0.3,linewidth=0.5)
    #ax4.clabel(con4,inline=True,fontsize=8)
    im4=ax4.imshow(dens.T, extent=[0, n*dx, 0, m*dy], origin='lower', cmap='viridis', alpha=1.0,vmin=fmin,vmax=fmax)
    #cbar=plt.colorbar(label='Rho',fraction=0.046, pad=0.04);
    div4=make_axes_locatable(ax4)
    cax4 = div4.append_axes("right", size="5%", pad=0.5)
    cbar4=plt.colorbar(im4,cax=cax4,label='Density',fraction=0.046, pad=0.04)
    #cax4.get_xaxis().get_major_formatter().set_useOffset(False)
    #cbar4.ax.set_yticklabels(['{:.0f}'.format(x) for x in np.arange(np.min(rho), np.max(rho),200)], fontsize=10, weight='normal')
    cbar4.ax.set_yticklabels(["{:.3f}".format(i) for i in cbar4.get_ticks()])


    ax5=plt.subplot(3,2,5)
    ax5.set_ylabel("Y")
    ax5.set_xlabel("X")
    ax5.set_title(title)
    im5 = ax5.imshow(np.log10(shear_strain.T), extent=[0, n*dx, 0, m*dy], origin='lower', cmap='magma', alpha=0.99)

    div5=make_axes_locatable(ax5)
    cax5 = div5.append_axes("right", size="5%", pad=0.5)
    cbar5=plt.colorbar(im5,cax=cax5,label='log SS',fraction=0.046, pad=0.04);

    ax6=plt.subplot(3,2,6)
    ax6.set_ylabel("Y")
    ax6.set_xlabel("X")
    ax6.set_title(title)
    im6 = ax6.imshow(np.log10(visc.T), extent=[0, n*dx, 0, m*dy], origin='lower', cmap='Spectral', alpha=0.99)
    div6=make_axes_locatable(ax6)
    cax6 = div6.append_axes("right", size="5%", pad=0.5)
    cbar6=plt.colorbar(im6,cax=cax6,label='log Visc',fraction=0.046, pad=0.04);


    plt.tight_layout()

    str1=str("{:05.0f}".format(l))
    filenm = dir_out+"/impact23_"+str1+".png"
    plt.tight_layout()
    plt.savefig(filenm)
    plt.close("all")


@njit(parallel=True)
def _solve_visc_kernel(n, m, th, omegaV, visc, fneq, rho, cx, cy, Y, grav,
                       T_top, T_base, visc_b, visc_cut, visc_scale, high_stress_visc, N,
                       shear_strain_out, alpha,
                       delta_eta, C0_MS98, tau1_MS98, depth_scale, L_lat):
    """Fused viscosity solve — parallel over grid points.
    All physics constants (delta_eta, C0_MS98, tau1_MS98, depth_scale, L_lat)
    are passed in from the driver's PhysParams; none are hard-coded here, so
    this stays in lockstep with the GPU k_visc kernel."""
    T_ave = (T_top + T_base)/2.0
    cxx = cx*cx
    cyy = cy*cy
    cxy = cx*cy
    # First pass: compute visc_T
    visc_T = np.empty((n+1, m+1))
    theta = np.log(delta_eta)
    for i in prange(n+1):
        for j in range(m+1):
            tmp = th[i,j]
            if tmp < T_top:
                tmp = T_top
            if tmp > T_base:
                tmp = T_base
            visc_T[i,j] = np.exp(-theta * tmp) #FK as per MS98
    # Normalize hot base (T=T_base) to visc_scale (fixed normalization,
    # matches the GPU kernel; independent of the current field min).
    vmin = np.exp(-theta * T_base)
    v0 = visc_scale / vmin
    # Second pass: scale, compute stress, apply plasticity
    m1 = L_lat
    v_l_K_l_over_L_l3 = visc_scale*alpha/(m1*m1*m1)
    v_k_K_l_over_L_l2 = visc_scale*alpha/(m1*m1)
    tau1_l = tau1_MS98*v_l_K_l_over_L_l3 #  × ν_ℓ κ_ℓ / L_ℓ³
    C0_l = C0_MS98 * v_k_K_l_over_L_l2 #τ₀_MS98 × ν_ℓ κ_ℓ / L_ℓ²
    for i in prange(n+1):
        for j in range(m+1):
            vT = visc_T[i,j] * v0
            if vT > visc_cut:
                vT = visc_cut
            S_prefac = 3.0 * omegaV[i,j] / (2.0 * rho[i,j])
            Sxx = 0.0; Syy = 0.0; Sxy = 0.0
            for k in range(9):
                fk = fneq[k,i,j]
                Sxx += fk * cxx[k]
                Syy += fk * cyy[k]
                Sxy += fk * cxy[k]
            I1 = Sxx + Syy
            I2 = Sxx*Syy - Sxy*Sxy
            J2 = abs((I1*I1)/3.0 - I2)
            eff_stress = np.sqrt(3.0 * J2)
            ss = abs(eff_stress * S_prefac)
            shear_strain_out[i,j] = ss
            ys = C0_l +tau1_l* ((1.0 - Y[i,j]) * depth_scale)
            stress = vT * ss
            if stress >= ys:
                vp = (ys / ss) ** N
                if vp < high_stress_visc:
                    vp = high_stress_visc
                visc[i,j] = vp
            else:
                visc[i,j] = vT
            omegaV[i,j] = 1.0/(3.0*visc[i,j]+0.5)


def solve_viscosity(Y, th, omegaV, visc, fneq, high_stress_visc, N, yield_stress,rho,cx,cy, T_top,T_base,grav,visc_b,visc_cut,visc_scale,alpha, params):
    n = th.shape[0] - 1
    m = th.shape[1] - 1
    shear_strain = np.empty_like(th)
    _solve_visc_kernel(n, m, th, omegaV, visc, fneq, rho, cx, cy, Y, grav,
                       T_top, T_base, visc_b, visc_cut, visc_scale, high_stress_visc, N,
                       shear_strain, alpha,
                       params.delta_eta, params.C0_MS98, params.tau1_MS98,
                       params.depth_scale, params.L_lat)
    return(visc, omegaV, shear_strain)



##################################################################
# Extemely slow - too many loops?
##################################################################


def run_loop(mstep,dt,m,n,gbeta,grav,cx,cy,omegaV,w,rho,th,C,vx,vy,f,feq,omegaT,T_top,T_base,g,geq,fc,fceq,H,alpha,X,Y,u0,dens,dir_out,Cp,im_file,visc,visc_b,visc_cut,visc_scale,high_stress_visc, N, yield_stress, params, t0=0):
    """GPU-resident main loop (CUDA port).

    All lattice fields live on the GPU for the whole run. Host transfers
    happen only at diagnostic/snapshot intervals. Per-step physics is
    identical to the CPU version: step_V == LB_D2Q9_V, step_T == LB_D2Q9_T,
    step_visc == solve_viscosity (validated to ~1e-15 against the CPU
    kernels).

    Behaviour changes vs CPU version:
      * The per-step min/max visc print and NaN checks now run every
        `print_step` steps (printing forces a device sync + copy; doing it
        every step would throttle the GPU).
      * The melt-column / impact block remains disabled (as in the CPU
        version). To re-enable it, follow the D2H/H2D pattern in the
        commented block below - the melt physics itself stays on the CPU.
    """
    nn = int(n/2)
    mm = int(m/2)
    img_step = 500      # Image snapshot interval
    dat_step = 50000     # Data snapshot interval
    ts_step  = 100      # Timeseries output interval
    print_step = 500    # min/max + NaN diagnostic interval (GPU port)
    # Restart support: resume counters so file numbering continues the sequence
    l = t0
    ll_img = int(np.ceil(t0/img_step))
    ll_dat = int(np.ceil(t0/dat_step))

    melt_dens = 2900
    melt_frac = np.zeros_like(th)
    Volc  = np.zeros_like(th)
    Depl  = np.zeros_like(th)
    Tmagma  = np.zeros_like(th)
    k_impact = 0

    # Background I/O thread pool - checkpoints and plots run async
    io_pool = ThreadPoolExecutor(max_workers=2)
    io_futures = []

    # Timeseries file - Nu and mobility written every ts_step
    ts_file = dir_out+"/timeseries.csv"
    with open(ts_file, 'w') as fts:
        fts.write("# timestep, Nu, surf_vrms, int_vrms, mobility\n")

    def _save_image(snap, ll_snap, dir_out, X, Y, XL, YL):
        """Background image save."""
        export_pic2(ll_snap, snap['th'], snap['vx'], snap['vy'],
                    X, Y, XL, YL, snap['C'], snap['dens'], snap['Volc'],
                    snap['Depl'], snap['melt_frac'], snap['shear_strain'],
                    snap['visc'], dir_out)

    def _save_data(snap, ll_snap, dir_out):
        """Background data save (full checkpoint incl. distributions for exact restart)."""
        np.savez(dir_out+"/"+str(ll_snap)+".npz", **snap)

    ############################################################
    # Upload state to the GPU. Everything below runs on-device.
    ############################################################
    dev = DeviceState(n, m, f, g, feq, geq, rho, vx, vy, th, dens, visc,
                      omegaV, Volc, Tmagma, Depl, C, H, x_Ts, x_Tl, Y,
                      w, cx, cy, params=params)
    dev.update_minmax_th()   # seeds tref for the first step_V

    for t in range(t0, mstep):
        """
        # -------- Melt columns + impacts (disabled, as in CPU version) ------
        # The melt physics stays on the CPU (it uses np.random and scipy
        # interpolation). If re-enabled, the transfer pattern is:
        #
        #   th_h = dev.th.copy_to_host();  C_h = dev.C.copy_to_host()
        #   dens_h = dev.dens.copy_to_host()
        #   melt_frac, Volc, Depl, Tmagma = loop_over_melt_columns(
        #       th_h, C_h, Y, x_Ts, x_Tl, dx, dt, dens_h, melt_dens)
        #   dev.Volc.copy_to_device(np.ascontiguousarray(Volc))
        #   dev.Depl.copy_to_device(np.ascontiguousarray(Depl))
        #   dev.Tmagma.copy_to_device(np.ascontiguousarray(Tmagma))
        #
        # For impacts: modify th_h/g on host via impact_time(), then
        #   dev.th.copy_to_device(th_h); dev.g.copy_to_device(g_h)
        #   dev.update_minmax_th()
        # At 301x301 these transfers are ~1 ms total - negligible unless
        # done every step at much larger grids.
        # --------------------------------------------------------------------
        """

        dev.step_V(gbeta, dt)                                     # == LB_D2Q9_V
        dev.step_T(omegaT, dt, Cp, T_top, T_base)                 # == LB_D2Q9_T
        dev.step_visc(T_top, T_base, visc_cut, visc_scale,
                      high_stress_visc, N, alpha)                 # == solve_viscosity

        # Diagnostics: min/max + NaN check every print_step (was every step on CPU)
        if (l % print_step == 0):
            """"visc_h = dev.visc.copy_to_host()
            ss_h   = dev.shear_strain.copy_to_host()
            th_h   = dev.th.copy_to_host()
            print("Timestep",t,np.min(visc_h),"/",np.max(visc_h)," ...",np.min(ss_h),"/",np.max(ss_h))
            if np.any(np.isnan(th_h)):
                  print("NAN in th")
            """
                    # Diagnostics: min/max + NaN + yield-fraction breakdown every print_step
        if (l % print_step == 0):
            visc_h = dev.visc.copy_to_host()
            ss_h   = dev.shear_strain.copy_to_host()
            th_h   = dev.th.copy_to_host()
            print("Timestep",t,np.min(visc_h),"/",np.max(visc_h),
                  " ...",np.min(ss_h),"/",np.max(ss_h))
            if np.any(np.isnan(th_h)):
                print("NAN in th")

            # --- Yield diagnostic (reconstructs the kernel's own test) ---
            # Recompute the PRE-yield FK viscosity vT exactly as k_visc does,
            # because dev.visc holds POST-yield values in yielded cells.
            # ALL constants pulled from params so this can never drift.
            theta   = np.log(params.delta_eta)
            visc_T  = np.exp(-theta * np.clip(th_h, T_top, T_base))
            v0      = visc_scale / np.exp(-theta * T_base)   # fixed-Tbase norm, matches kernel
            vT      = np.minimum(visc_T * v0, visc_cut)
            # Yield stress field, same expression + constants as the kernel:
            m1      = params.L_lat
            C0_l    = params.C0_MS98 * (visc_scale * alpha / (m1*m1))
            tau1_l  = params.tau1_MS98 * (visc_scale * alpha / (m1*m1*m1))
            ys_f    = C0_l + tau1_l * ((1.0 - Y) * params.depth_scale)
            # The kernel tests stress = vT*ss >= ys:
            stress  = vT * ss_h
            yielded = stress >= ys_f
            ftot = yielded.mean()
            # Rows: axis=1 is j (depth); j=m is the free-slip surface.
            def rowfrac(jj): return yielded[:, jj].mean()
            print(f"  YIELD frac tot={ftot:.4f}  "
                  f"j=m(surf)={rowfrac(-1):.4f}  m-1={rowfrac(-2):.4f}  "
                  f"m-2={rowfrac(-3):.4f}  m-3={rowfrac(-4):.4f}  "
                  f"interior(3:-3)={yielded[:,3:-3].mean():.4f}")
            # Sxy sanity on the surface vs one row in: free-slip => surface Sxy~0.
            # Rebuild deviatoric moments from fneq for rows j=m and j=m-1.
            fneq_h = dev.fneq.copy_to_host()
            cxh = cx; cyh = cy
            Sxy_m  = np.einsum('kij,k->ij', fneq_h[:,:,-1:], cxh*cyh)
            Sxy_m1 = np.einsum('kij,k->ij', fneq_h[:,:,-2:-1], cxh*cyh)
            Sxx_m1 = np.einsum('kij,k->ij', fneq_h[:,:,-2:-1], cxh*cxh)
            Syy_m1 = np.einsum('kij,k->ij', fneq_h[:,:,-2:-1], cyh*cyh)
            denom  = np.abs(Sxx_m1).mean() + np.abs(Syy_m1).mean() + 1e-30
            print(f"  Sxy |surface|={np.abs(Sxy_m).mean():.3e}  "
                  f"|row m-1|={np.abs(Sxy_m1).mean():.3e}  "
                  f"ratio_surf/(normal_m1)={np.abs(Sxy_m).mean()/denom:.3f}")
            dY = Y[0,1]-Y[0,0]
            # signed fluxes, one cell in from each boundary
            Nu_top = np.mean(th_h[:,-3]-th_h[:,-2])/dY/(T_base-T_top)
            Nu_bot = np.mean(th_h[:,1]-th_h[:,2])/dY/(T_base-T_top)
            Tmean  = th_h.mean()
            print(f"  BUDGET Nu_top={Nu_top:.3f} Nu_bot={Nu_bot:.3f} "
                  f"imbalance={Nu_bot-Nu_top:+.3f}  <T>={Tmean:.5f}")
            vy_h = dev.vy.copy_to_host()
            kap  = alpha
            qref = kap*(T_base-T_top)/m           # pure-conduction flux, lattice units
            dTdz = np.gradient(th_h, axis=1)      # per cell
            Nu_z = (np.mean(vy_h*th_h, axis=0) - kap*np.mean(dTdz, axis=0))/qref
            nz = Nu_z.shape[0]
            js = sorted(set([1, 2, 5]
                            + [int(f*(nz-1)) for f in (0.1, 0.25, 0.5, 0.75, 0.9)]
                            + [nz-3, nz-2]))
            js = [j for j in js if 0 <= j < nz]
            print("  Nu(z): " + "  ".join(f"j{j}={Nu_z[j]:.2f}" for j in js))


        # Timeseries: Nu and mobility every ts_step
        if (l % ts_step == 0):
            th_h = dev.th.copy_to_host()
            vx_h = dev.vx.copy_to_host()
            vy_h = dev.vy.copy_to_host()
            vmag = np.sqrt(vx_h*vx_h + vy_h*vy_h)
            # Surface vrms - top 5% of domain
            surf_mask = (Y > 0.95)
            surf_vrms = np.sqrt(np.mean(vmag[surf_mask]**2)) if np.any(surf_mask) else 0.0
            # Interior vrms - middle 60% of domain
            int_mask = (Y > 0.2) & (Y < 0.8)
            int_vrms = np.sqrt(np.mean(vmag[int_mask]**2)) if np.any(int_mask) else 1e-30
            mobility = surf_vrms / int_vrms
            # Nusselt number - top boundary heat flux / conductive flux
            dTdz_top = np.mean(np.abs(th_h[:,-1] - th_h[:,-2])) / (Y[0,-1] - Y[0,-2])
            Nu = dTdz_top / (T_base - T_top)
            with open(ts_file, 'a') as fts:
                fts.write(f"{l}, {Nu:.6f}, {surf_vrms:.8e}, {int_vrms:.8e}, {mobility:.6f}\n")

        # Backpressure: prune finished I/O jobs; if the backlog is too deep,
        # block until it drains.
        if (l % img_step == 0):
            io_futures = [fu for fu in io_futures if not fu.done()]
            while len(io_futures) >= 4:
                io_futures.pop(0).result()

        # Image snapshots every img_step (device -> host copies of fields)
        if (l % img_step == 0):
            snap = dict(th=dev.th.copy_to_host(), vx=dev.vx.copy_to_host(),
                        vy=dev.vy.copy_to_host(),
                        C=dev.C.copy_to_host(), dens=dev.dens.copy_to_host(),
                        Volc=dev.Volc.copy_to_host(),
                        Depl=dev.Depl.copy_to_host(), melt_frac=melt_frac.copy(),
                        visc=dev.visc.copy_to_host(),
                        shear_strain=dev.shear_strain.copy_to_host())
            fut = io_pool.submit(_save_image, snap, ll_img, dir_out, X, Y, XL, YL)
            io_futures.append(fut)
            print("IMG",ll_img,l)
            ll_img += 1

        # Data snapshots every dat_step - includes f, g, rho and timestep for exact restart
        if (l % dat_step == 0):
            snap_d = dict(th=dev.th.copy_to_host(), vx=dev.vx.copy_to_host(),
                        vy=dev.vy.copy_to_host(),
                        C=dev.C.copy_to_host(), dens=dev.dens.copy_to_host(),
                        Volc=dev.Volc.copy_to_host(),
                        Depl=dev.Depl.copy_to_host(), melt_frac=melt_frac.copy(),
                        visc=dev.visc.copy_to_host(),
                        shear_strain=dev.shear_strain.copy_to_host(),
                        f=dev.f.copy_to_host(), g=dev.g.copy_to_host(),
                        rho=dev.rho.copy_to_host(),
                        timestep=np.array(l))
            fut = io_pool.submit(_save_data, snap_d, ll_dat, dir_out)
            io_futures.append(fut)
            print("DATA",ll_dat,l)
            ll_dat += 1

        l += 1

    # Wait for any remaining background I/O to finish
    for fut in io_futures:
        try:
            fut.result()
        except Exception as e:
            print(f"Background I/O error: {e}")
    io_pool.shutdown(wait=True)

    # Final state back to host
    th = dev.th.copy_to_host()
    vx = dev.vx.copy_to_host()
    vy = dev.vy.copy_to_host()
    rho = dev.rho.copy_to_host()
    C = dev.C.copy_to_host()
    return th, vx, vy, rho, C


def calc_Nu(X,Y,th,T_top,T_base,alpha,m,t):
    filt1 = ( ((Y> 0.9)&(Y<1.0)) & (th< 0.5) )
    dTdz =  np.mean(-1.0*(T_top - th[filt1])/(1.0 - Y[filt1])) #Assumed going up
    q_conv = alpha * dTdz  #alpha = k/rho*Cp  --> assume in lattice units rho=Cp=1
    q_cond = alpha * (T_base - T_top) # Note that m lattice units would appear in conv and cond and thus cancels out
    Nu = q_conv / q_cond
    fopen = open('Nu_t.csv','ab')
    np.savetxt(fopen, np.c_[float(t), float(Nu)],newline='\n')
    fopen.close()


def add_impact_heat(X,Y,xp,yp,th,g,R,vel,Cp,m):
    #Note R is in km, vel is in km/s
    # See Melosh (1989) or O'Neill et al. (2017) for terms
    # Tillotson constants
    C=7.24 #km/s
    S=1.25
    a=1.68
    b=2.74
    # Escape vel
    if (vel < 11.0):
        vel = 11.0
    d = 0.305*R*vel**0.361
    rc = 0.451*R*vel**0.211 *1e3
    r = np.linspace(0, 5*R,50)*1e3 #m
    u = (vel/2) *1e3 #m/s
    Ps = np.zeros_like(r)
    k=0
    for r2 in r:
        Ps[k] =  3400 * (C + S*u)*u
        if r2 > rc:
            Ps[k] =  Ps[0]*( (rc/r2)**(-a+b*np.log10(vel)) )
        k+=1
    #print(i, age[i]," Ma ","R",R[i], " rc",rc,"uc",u,"Ps",np.max(Ps)/1e9)
    f=(-2*S*Ps/(C*C*3400)) * ( 1.0 / (1 - np.sqrt( ((4*S*Ps)/(C*C*3400)) + 1)) )
    dT = (1/Cp) * ( (Ps/(C*C*3400))*(1 - (1/f) ) - ( (C**2/(S**2)) * (f - np.log(f) - 1)))
    # Reference to position, xp, yp
    rm = r * 1/660e3   #Scale to LB units
    rcm = rc *1/660e3
    xpm = 2 * ((xp)/12 ) # Long to L.U.
    ypm = d/660 # Emplacement depth is d
    f = interp1d(r,dT)
    r2 = np.sqrt( (X-xpm)**2 + ((1-Y) - ypm)**2)
    print("Scales - X/y:",np.max(X),np.max(Y),np.max(R),np.max(rm),np.max(r2),np.max(rcm),"Centre: (",xpm,ypm,")")
    
    filt1= (r2 < np.max(rm) )  #r2 is 2D, r is 1D
    dT2 = np.zeros_like(th)
    dT2[filt1] = f(r2[filt1]) #Interpolate dT to r2
    th += dT2
    filt1 = th > x_Tl
    th[filt1] = x_Tl[filt1]
    g[0,:,:] =  w[0]*th
    g[1,:,:] =  w[1]*th
    g[2,:,:] =  w[2]*th
    g[3,:,:] =  w[3]*th
    g[4,:,:] =  w[4]*th
    g[5,:,:] =  w[5]*th
    g[6,:,:] =  w[6]*th
    g[7,:,:] =  w[7]*th
    g[8,:,:] =  w[8]*th #
    return (th, g)

def impact_time(X,Y,th,g,Cp,m,im_file,k_impact):
    # Define xp, yp here from input long
    lon = np.genfromtxt(im_file,usecols=1)
    # From age list, get appropriate impact
    ages = np.genfromtxt(im_file,usecols=0)
    #i = np.argmin(np.abs(ages - t))
    xp = lon[k_impact]
    yp = 0.0

    R = np.genfromtxt(im_file,usecols=3)[k_impact]
    vel = np.genfromtxt(im_file,usecols=4)[k_impact]
    th, g = add_impact_heat(X,Y,xp,yp,th,g,R,vel,Cp,m)
    return (th, g)


############################################################################################
# Bespoke thermal ICs

thermal_pulse_on = True
#Initial simple thermal/impact pulse
def thermal_pulse(thermal_pulse_on,X,Y,th):
  if thermal_pulse_on==True:
    R = np.sqrt((X-1.0)**2 + (Y-0.05)**2)
    filtR = (R < 0.2)&(Y<0.95)
    th[filtR] += 0.05
    R = np.sqrt((X-0.0)**2 + (Y-0.05)**2)
    filtR = (R < 0.2)&(Y<0.95)
    th[filtR] += 0.02
    R = np.sqrt((X-2.0)**2 + (Y-0.05)**2)
    filtR = (R < 0.2)&(Y<0.95)
    th[filtR] += 0.05
    return(th)

# Impact heating############################################################################
# See O'Neill et al. 2017 for further details and parameters.
#Initial thermal/impact pulse
# Imposing single impact here

impact_heat_IC_on=False

def impact_heat_IC(impact_heat_IC_on,X,Y,th):
  if impact_heat_IC_on==True:
    ND_T = 2000 #UM-LM non-adiabatic temperature

    R = np.sqrt((X-1.0)**2 + (Y-0.95)**2)
    filtR = (R < 0.75)&(Y<0.95)

    Ri = 100.0 #km
    vel = 26.0  # escape vel, km/s
    Ci=7.24 #km/s
    S=1.25
    a=1.68
    b=2.74
    Cp=840
    M2S = 1e6*365.25*24*60*60

    d = 0.305*Ri*vel**0.361
    rc = 0.451*Ri*vel**0.211 *1e3
    r = np.linspace(0, 20*Ri,75)*1e3 #m - for calculating shells of heating
    u = (vel/2) *1e3 #m/s

    Ps = np.zeros_like(r)
    k=0
    for r2 in r:
     Ps[k] =  3400 * (Ci + S*u)*u
     if r2 > rc:
         Ps[k] =  Ps[0]*( (rc/r2)**(-a+b*np.log10(vel)) )
     k+=1
    f_imp=(-2*S*Ps/(Ci*Ci*3400)) * ( 1.0 / (1 - np.sqrt( ((4*S*Ps)/(Ci*Ci*3400)) + 1)) )
    dT = (1/Cp) * ( (Ps/(Ci*Ci*3400))*(1 - (1/f_imp) ) - ( (Ci**2/(S**2)) * (f_imp - np.log(f_imp) - 1))) # function of r
    print(np.c_[r/(1e3*660),dT/ND_T])
    print("dT:",np.min(dT),np.max(dT))
    # Interpolate to X,Y grid
    f_imp=interp1d(r/(660*1e3),dT/ND_T,fill_value=(np.max(dT)/ND_T,0),bounds_error=False) #Non-Dim the relationship for grid interp
    dT_X = f_imp(np.ravel(R))
    dT_X = dT_X.reshape(X.shape)
    #np.set_printoptions(threshold=np.inf)
    print(np.c_[np.ravel(R[dT_X>0.1]),np.ravel(dT_X[dT_X>0.1])])
    #dT_X = dT_X.reshape(X.shape)
    print("dT_X:",np.min(dT_X),np.max(dT_X))

    #th += dT_X
    #th[filtR] += dT_X[filtR] # The example shown restricts the impact influence radially and prevents crustal disturbance. Remove filter to remove these effects. 
    th[th>1.0] = 1.0  # Cap to effective liquidus. 
    return th


##############################################################################################################################################################
#Geometry
m=64 #300
n=64 #300

dist_x = 1.0
dist_y = 1.0
# Backing out increments
dx = dist_x/n
dy= dist_y/m
dt=1.000  # This should have no effect except on H 

# Initiatialise grid
x = np.arange(0,dist_x+dx,dx) #Not n+1 ... mmm.
y = np.arange(0,dist_y+dy,dy)
#print(y)
X,Y = np.meshgrid(x,y) # Change rows to columns
X=X.T
Y=Y.T

f=np.zeros((9,n+1,m+1))
feq=np.zeros((9,n+1,m+1))

fc=np.zeros((9,n+1,m+1))
fceq=np.zeros((9,n+1,m+1))

g=np.zeros((9,n+1,m+1))
geq=np.zeros((9,n+1,m+1))

w = np.zeros((9))
cx = np.zeros((9))
cy = np.zeros((9))

u0="free" # for single value: 0.0 or for array: np.ones_like(x)*0.01
grav=1.0  # No point scaling this - inf Pr comes into dimensional scaling
beta=1e-5 #Keep same, 1e-5
gbeta = grav*beta

#This is dimensionalised in melt calcs - taken care of internally (rho < 4000 kg/m3). 
rho0=1.0  #Non-dim version
dens0 = 3400 #Dim version for melting
Cp=1.0

rho=np.ones((n+1,m+1))*rho0
dens=np.ones((n+1,m+1))*dens0

###################################################
#ICs
##################################################
# Vel conditions
if (type(u0) == float)or(type(u0) == np.array):
    vx=np.ones((n+1,m+1))*u0
else:
    vx=np.zeros((n+1,m+1))
vy=np.zeros((n+1,m+1))
th=np.ones((n+1,m+1))
C=np.ones((n+1,m+1))

# T conditions
T_top=0.0 #1  # Avoids singularities in viscosity laws
T_base=1.0 #1 # 0.001
T_ave = (T_top + T_base)/2.0

C1 = np.linspace(0.00,0.0,m+1)
z1=np.linspace(660e3,0,m+1)
# Age of litho being thinned - 350 Myr here.
T1 = 0.9*erf((z1)/(2*np.sqrt(1e-6*(45*1e6*60*60*24*365.25))))
T2 = 0.9*erf((z1)/(2*np.sqrt(1e-6*(90*1e6*60*60*24*365.25))))
for j in np.arange(0,m+1,1):
    th[:,j] = th[:,j]*T2[j]
    C[:,j] = C[:,j]*C1[j]

th = thermal_pulse(thermal_pulse_on,X,Y,th)

T_ave = (np.min(th) + np.max(th))/2
rho = rho*(1 - beta*(th - T_ave))

density_S = [3200,3400, 3050, 2900]
C_S = [-1, 0, 1, 1.5]
fii = interp1d(C_S,density_S,fill_value=(3200,2900),bounds_error=False)
dens = fii(C)


print("Shapes",np.shape(X),np.shape(Y),np.shape(th))

#########################################################################################
# Initialise variables
sol = (np.genfromtxt("../data/stixrude_sol.txt",usecols=0) )
sol_x = (np.genfromtxt("../data/stixrude_sol.txt",usecols=1))
sol = sol - 0.15*sol_x #Remove adiabatic gradient
sol = (sol - 273.0 ) /2000.0 # Scale
sol_x = sol_x*1e3 / 660e3

fi=interp1d(sol_x,sol,fill_value="extrapolate")
#Y2 = np.flipud(Y)
Y2 = Y*(-1.0) + 1.0 # Checked.
x_Ts = fi(Y2)
#print("x_Ts_2:",np.shape(x_Ts),x_Ts.dtype)
x_Tl = x_Ts + 0.3 #assumed liquidus is just 300C above solidus for now.

w=np.zeros(9)
w[0]=4./9.
w[1]=w[2]=w[3]=w[4]=1./9.
w[5]=w[6]=w[7]=w[8]=1./36.

cx = np.array([0.0,1.0,0.0,-1.0,0.0,1.0,-1.0,-1.0,1.0])
cy = np.array([0.0,0.0,1.0,0.0,-1.0,1.0,1.0,-1.0,-1.0])


# S' = d'**2/( K' * T'),  d'=4e6/(0.00130 * 2000) & / Cp(=1000) for LB sources
# H_mantle_nonchron = 3.2468e-12 W/kg
Hm = 0.0 #4.9797e-9 # + 5.6135e-8
H=np.ones_like(th)* Hm

ra=1e4 #1e7 #4.167e4 # Might be slightly subcritical if ~1e4
pr=1e3 #Mora 23. sqrt(pr)~31.62

##################################################################################################
# Scalings
##################################################################################################

Kl = np.sqrt(gbeta*(T_base - T_top)*((m-1)**3)/ra)

vl=Kl*np.sqrt(pr)
kl = Kl/(np.sqrt(pr))


dxp = 2890e3/(m-1)
dtp = (kl/1e-6) * (dxp**2)

print("Kl term:",Kl,np.sqrt(pr))
print("x scaling:",dxp,"time scaling:",dtp) #9665m, 1.5e10s
print("visc scaling,",vl,"diff scaling:",kl) # 0.16, 1.6e-4

##################################################################################################
# SINGLE SOURCE OF TRUTH for all physics constants used by the LB kernels.
# Both the GPU kernels (via DeviceState) and the CPU _solve_visc_kernel read
# from this object, so they can never drift apart again. To change a constant,
# change it HERE and nowhere else.
##################################################################################################
phys = PhysParams(
    delta_eta   = 1.0, #3e4,      # FK total viscosity contrast (MS98)
    C0_MS98     = 1e5,      # cohesion yield stress in MS98 units  <-- set target regime here
    tau1_MS98   = 1e7,      # yield-stress depth gradient (MS98 units)
    depth_scale = 300.0,    # (1-Y)*depth_scale factor in the yield law
    cdens_ref   = 2900.0,   # compositional density reference [kg/m^3]
    cdens_span  = 500.0,    # compositional density span (=3400-2900) [kg/m^3]
    eff_fac     = 5e-4,     # volcanic velocity-source efficiency
    gbeta10     = 0.0,      # compositional buoyancy coefficient
    prefac_D    = 1e-4,     # depletion-refrigeration efficiency
    prefac_V    = 1e-4,     # volcanic-heating efficiency
    sink_prefac = 0.0,      # runaway-thermal sink prefactor
    L_lat       = m - 1,    # lattice length in the stress conversion (matches CPU m1)
    magic       = 3.0/16.0, # TRT magic parameter Lambda (stabilizes stiff lid)
)
# Module-level mirror of the TRT magic parameter, used by the CPU warmup
# collision (LB_D2Q9_V -> _collision_force_V). Kept identical to phys.magic.
MAGIC_TRT = phys.magic

#visco=0.1 #0.0405  # Modified to slow down convection - CO 13/Apr/2023

##################################################################################################

##################################################################################################
# T-dep viscosity. Here we initialise omega matrix, and update it after the temperature step
#

#visco2 = (gbeta*(T_base - T_top) * (m-1)**3 )/(ra * 1/pr)  #Note density is removed from this, so assumed non-dim here
#visc_scale = np.sqrt(visco2) # 1.634958684493281

visc_scale = vl

#Arrhenius law
""""
R=1
E=8.5 #5.5
# Mora formulation
visc_b = 5*E/T_ave
visc2 = np.exp(visc_b * (T_ave/th - 1)/(T_ave/T_top - 1))
v0 = (visc_scale/np.min(visc2))
visc2 = visc2 * v0
visc = visc2
visc_cut=5e5
visc[visc>visc_cut] = visc_cut
omegaV=1.0/(3.*visc+0.5)
"""

# FK law init
visc_cut=5e5
visc_b=1
theta_fk = np.log(phys.delta_eta)
visc = np.exp(-theta_fk*np.clip(th, T_top, T_base))
visc *= visc_scale/np.exp(-theta_fk*T_base)
visc = np.minimum(visc, visc_cut)
omegaV = 1.0/(3.*visc+0.5)

high_stress_visc = 0.01 * visc_scale
N =  1.0
shear_strain = 1.0e-5
yield_stress = 0.8 * visc_scale * np.max(shear_strain) # Note shear strain is not calculated till within the loop. Need a priori info for this. Start high and rely on updating




#alpha=visco/pr  #Their alpha ~ thermal diffusivity. I think this is too small. 
alpha=kl #visco2/pr
Cdiff=6e-5 #Compositional diffusion

print("Ra=",ra,"gbeta:",gbeta)
omegaT=1.0/(3.*alpha+0.5)

"""
omegaC=1.0*np.ones_like(C)/(3*Cdiff+0.5) #assumed dt and csq are 1... omegaC=1.0/(3*Cdiff/(dt*csq)+0.5)
# Increase diff to counter corner instabilities
filtC1 = (Y>0.9)&(X<0.1)
omegaC[filtC1] = 1.0/(3*18*Cdiff+0.5)
filtC2 = (Y>0.9)&(X>1.9)
omegaC[filtC2] = 1.0/(3*18*Cdiff+0.5)
"""

mstep=2500000000 #150000
#print("Omegas",omegaV,omegaT,omegaC,alpha,visco)


dir_out=str(datetime.now().strftime('%Y_%m_%d_%H_%M'))
os.makedirs(dir_out, exist_ok=True)
file_out = dir_out+"/input.py"
shutil.copy(__file__, file_out)
file_2 = dir_out+"/XY.dat"
np.savetxt(file_2,np.c_[np.ravel(X),np.ravel(Y)])

# Initial vels
Volc = np.zeros_like(th)
# Low resolution for plotting velocity field
XL,YL = np.meshgrid(np.linspace(0,1,40),np.linspace(0,1,20))
#Run main

feq = loopy_loop(n,m,vx,vy,cx,cy,rho,w,feq)

geq[0,:,:] = w[0]*th*(1.0+3.0*(vx*cx[0]+ vy*cy[0]))
geq[1,:,:] = w[1]*th*(1.0+3.0*(vx*cx[1]+ vy*cy[1]))
geq[2,:,:] = w[2]*th*(1.0+3.0*(vx*cx[2]+ vy*cy[2]))
geq[3,:,:] = w[3]*th*(1.0+3.0*(vx*cx[3]+ vy*cy[3]))
geq[4,:,:] = w[4]*th*(1.0+3.0*(vx*cx[4]+ vy*cy[4]))
geq[5,:,:] = w[5]*th*(1.0+3.0*(vx*cx[5]+ vy*cy[5]))
geq[6,:,:] = w[6]*th*(1.0+3.0*(vx*cx[6]+ vy*cy[6]))
geq[7,:,:] = w[7]*th*(1.0+3.0*(vx*cx[7]+ vy*cy[7]))
geq[8,:,:] = w[8]*th*(1.0+3.0*(vx*cx[8]+ vy*cy[8])) 

"""
fceq[0,:,:] = w[0]*C*(1.0+3.0*(vx*cx[0]+ vy*cy[0]))
fceq[1,:,:] = w[1]*C*(1.0+3.0*(vx*cx[1]+ vy*cy[1]))
fceq[2,:,:] = w[2]*C*(1.0+3.0*(vx*cx[2]+ vy*cy[2]))
fceq[3,:,:] = w[3]*C*(1.0+3.0*(vx*cx[3]+ vy*cy[3]))
fceq[4,:,:] = w[4]*C*(1.0+3.0*(vx*cx[4]+ vy*cy[4]))
fceq[5,:,:] = w[5]*C*(1.0+3.0*(vx*cx[5]+ vy*cy[5]))
fceq[6,:,:] = w[6]*C*(1.0+3.0*(vx*cx[6]+ vy*cy[6]))
fceq[7,:,:] = w[7]*C*(1.0+3.0*(vx*cx[7]+ vy*cy[7]))
fceq[8,:,:] = w[8]*C*(1.0+3.0*(vx*cx[8]+ vy*cy[8]))
"""

f[0,:,:] =  w[0]*rho
f[1,:,:] =  w[1]*rho
f[2,:,:] =  w[2]*rho
f[3,:,:] =  w[3]*rho
f[4,:,:] =  w[4]*rho
f[5,:,:] =  w[5]*rho
f[6,:,:] =  w[6]*rho
f[7,:,:] =  w[7]*rho
f[8,:,:] =  w[8]*rho

g[0,:,:] =  w[0]*th
g[1,:,:] =  w[1]*th
g[2,:,:] =  w[2]*th
g[3,:,:] =  w[3]*th
g[4,:,:] =  w[4]*th
g[5,:,:] =  w[5]*th
g[6,:,:] =  w[6]*th
g[7,:,:] =  w[7]*th
g[8,:,:] =  w[8]*th

"""
fc[0,:,:] =  w[0]*C
fc[1,:,:] =  w[1]*C
fc[2,:,:] =  w[2]*C
fc[3,:,:] =  w[3]*C
fc[4,:,:] =  w[4]*C
fc[5,:,:] =  w[5]*C
fc[6,:,:] =  w[6]*C
fc[7,:,:] =  w[7]*C
fc[8,:,:] =  w[8]*C

"""

usum = f[0,:,:]*cx[0] + f[1,:,:]*cx[1] + f[2,:,:]*cx[2] + f[3,:,:]*cx[3] + f[4,:,:]*cx[4] +f[5,:,:]*cx[5] + f[6,:,:]*cx[6] +f[7,:,:]*cx[7]+f[8,:,:]*cx[8]
vsum = f[0,:,:]*cy[0] + f[1,:,:]*cy[1] + f[2,:,:]*cy[2] + f[3,:,:]*cy[3] + f[4,:,:]*cy[4] +f[5,:,:]*cy[5] + f[6,:,:]*cy[6] +f[7,:,:]*cy[7]+f[8,:,:]*cy[8]
vx = usum/rho
vy = vsum/rho

rho, vx, vy, f, fneq = LB_D2Q9_V(dt,m,n,gbeta,cx,cy,omegaV,w,rho,th,vx,vy,f,feq,u0, Volc, Volc)
th, g = LB_D2Q9_T(dt,m,n,cx,cy,omegaT,w,T_top,T_base,th,vx,vy,g,geq,H,Volc,0,x_Ts,Volc,Cp,Y)
#C, dens, fc = LB_D2Q9_C(dt,m,n,cx,cy,omegaC,w,th,vx,vy,fc,fceq,C,Volc,dens,rho,0)        
visc, omegaV, shear_strain = solve_viscosity(Y, th, omegaV, visc, fneq, high_stress_visc, N, yield_stress,rho,cx,cy,  T_top,T_base,grav, visc_b,visc_cut,visc_scale,alpha, phys)

vx=0.0*vx
vy=0.0*vy

##################################################################################################
# RESTART: set to a checkpoint .npz path (e.g. "2026_07_18_10_30/446.npz") to resume, else None.
# New-format checkpoints (with f, g, rho, timestep) restart exactly at the stored timestep.
# Old-format checkpoints restart approximately: distributions rebuilt at equilibrium
# from the saved macroscopic fields — expect a short transient.
#
# The raw timestep is derived automatically from the npz filename:
#   raw timestep = npz_number * dat_step(=5000)     [NOT * img_step(=500)!]
# so 117.npz -> t0 = 585000 -> images resume at impact23_01170.png.
# RESTART_T0 (raw timestep) is an optional manual override; leave at 0 to auto-derive.
##################################################################################################
RESTART_FILE = None #"2026_07_20_16_29/499.npz"
RESTART_T0 = 0
RESTART_DAT_STEP = 0 #5000   # must match dat_step in run_loop

t0 = 0
if RESTART_FILE is not None:
    ck = np.load(RESTART_FILE)
    th   = ck['th'];  C    = ck['C'];  dens = ck['dens']
    vx   = ck['vx'];  vy   = ck['vy']; visc = ck['visc']
    if 'rho' in ck.files:
        rho = ck['rho']
    if ('f' in ck.files) and ('g' in ck.files):
        f = ck['f']
        g = ck['g']
    else:
        # Old checkpoint: rebuild distributions at local equilibrium
        feq = loopy_loop(n,m,vx,vy,cx,cy,rho,w,feq)
        f = feq.copy()
        _compute_geq(n, m, w, cx, cy, th, vx, vy, geq)
        g = geq.copy()
    omegaV = 1.0/(3.0*visc + 0.5)
    if 'timestep' in ck.files:
        t0 = int(ck['timestep'])                 # exact, stored by new-format checkpoints
    elif RESTART_T0 > 0:
        t0 = int(RESTART_T0)                     # manual override (raw timestep)
    else:
        # Derive from filename: npz number * dat_step
        npz_num = int(os.path.splitext(os.path.basename(RESTART_FILE))[0])
        t0 = npz_num * RESTART_DAT_STEP
    ck.close()
    print("RESTART from", RESTART_FILE, "at raw timestep", t0,
          "-> images resume at impact23_%05d.png, data at %d.npz" % (t0//500, t0//RESTART_DAT_STEP))

# Impacts
#im_file = "impact_subset.dat"
im_file="../data/Impacts_lon204.dat"
#im_file=None
th, vx, vy, rho, C = run_loop(mstep,dt,m,n,gbeta,grav,cx,cy,omegaV,w,rho,th,C,vx,vy,f,feq,omegaT,T_top,T_base,g,geq,fc,fceq,H,alpha,X,Y,u0,dens,dir_out,Cp,im_file,visc,visc_b,visc_cut,visc_scale,high_stress_visc, N, yield_stress, phys, t0=t0)





